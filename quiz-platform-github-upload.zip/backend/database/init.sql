-- Initialize database for competitive quiz platform
-- This script runs when the PostgreSQL container starts

-- Create extensions if needed
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- The actual tables will be created by Prisma migrations
-- This file ensures the database is ready for Prisma