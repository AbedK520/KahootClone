#!/bin/bash

echo "🚀 Starting Quiz Platform Backend Deployment..."

# Update system
sudo yum update -y

# Install Node.js 18
curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -
sudo yum install -y nodejs

# Install PM2 globally
sudo npm install -g pm2

# Install git if not present
sudo yum install -y git

# Clone the repository
git clone https://github.com/YOUR_USERNAME/quiz-platform.git
cd quiz-platform/backend

# Copy production environment
cp .env.production .env

# Install dependencies
npm install

# Generate Prisma client for SQLite
npx prisma generate

# Run database migrations
npx prisma migrate deploy

# Build the application
npm run build

# Seed the database with sample questions
npm run seed

# Start the application with PM2
pm2 start dist/server.js --name "quiz-backend"
pm2 startup
pm2 save

echo "✅ Backend deployment complete!"
echo "🌐 Backend running on port 3001"