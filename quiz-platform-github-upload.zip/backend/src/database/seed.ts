import { PrismaClient, QuestionType, Difficulty } from '@prisma/client';

const prisma = new PrismaClient();

interface SeedQuestion {
  text: string;
  type: QuestionType;
  category: string;
  difficulty: Difficulty;
  options?: string[];
  correctAnswer: string;
  explanation?: string;
}

const questions: SeedQuestion[] = [
  // Science - Easy
  {
    text: "What is the chemical symbol for water?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "Science",
    difficulty: Difficulty.EASY,
    options: ["H2O", "CO2", "NaCl", "O2"],
    correctAnswer: "H2O",
    explanation: "Water is composed of two hydrogen atoms and one oxygen atom, hence H2O."
  },
  {
    text: "The Sun is a star.",
    type: QuestionType.TRUE_FALSE,
    category: "Science",
    difficulty: Difficulty.EASY,
    correctAnswer: "true",
    explanation: "The Sun is indeed a star - a medium-sized yellow dwarf star."
  },
  {
    text: "How many legs does a spider have?",
    type: QuestionType.TEXT_INPUT,
    category: "Science",
    difficulty: Difficulty.EASY,
    correctAnswer: "8",
    explanation: "All spiders have eight legs, which distinguishes them from insects."
  },

  // Science - Medium
  {
    text: "What is the powerhouse of the cell?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "Science",
    difficulty: Difficulty.MEDIUM,
    options: ["Nucleus", "Mitochondria", "Ribosome", "Endoplasmic Reticulum"],
    correctAnswer: "Mitochondria",
    explanation: "Mitochondria produce ATP, the energy currency of cells."
  },
  {
    text: "DNA stands for Deoxyribonucleic Acid.",
    type: QuestionType.TRUE_FALSE,
    category: "Science",
    difficulty: Difficulty.MEDIUM,
    correctAnswer: "true",
    explanation: "DNA is indeed Deoxyribonucleic Acid, the molecule that carries genetic information."
  },

  // Science - Hard
  {
    text: "What is the speed of light in a vacuum?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "Science",
    difficulty: Difficulty.HARD,
    options: ["299,792,458 m/s", "300,000,000 m/s", "186,000 miles/s", "3 × 10^8 m/s"],
    correctAnswer: "299,792,458 m/s",
    explanation: "The exact speed of light in a vacuum is 299,792,458 meters per second."
  },

  // Geography - Easy
  {
    text: "What is the capital of France?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "Geography",
    difficulty: Difficulty.EASY,
    options: ["London", "Berlin", "Paris", "Madrid"],
    correctAnswer: "Paris",
    explanation: "Paris is the capital and largest city of France."
  },
  {
    text: "Australia is both a country and a continent.",
    type: QuestionType.TRUE_FALSE,
    category: "Geography",
    difficulty: Difficulty.EASY,
    correctAnswer: "true",
    explanation: "Australia is unique in being both a country and a continent."
  },
  {
    text: "Which ocean is the largest?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "Geography",
    difficulty: Difficulty.EASY,
    options: ["Atlantic", "Pacific", "Indian", "Arctic"],
    correctAnswer: "Pacific",
    explanation: "The Pacific Ocean is the largest ocean, covering about 46% of Earth's water surface."
  },

  // Geography - Medium
  {
    text: "What is the longest river in the world?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "Geography",
    difficulty: Difficulty.MEDIUM,
    options: ["Amazon", "Nile", "Mississippi", "Yangtze"],
    correctAnswer: "Nile",
    explanation: "The Nile River is approximately 6,650 km long, making it the longest river."
  },
  {
    text: "Mount Everest is located in Nepal.",
    type: QuestionType.TRUE_FALSE,
    category: "Geography",
    difficulty: Difficulty.MEDIUM,
    correctAnswer: "true",
    explanation: "Mount Everest is located on the border between Nepal and Tibet (China)."
  },

  // Geography - Hard
  {
    text: "What is the smallest country in the world?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "Geography",
    difficulty: Difficulty.HARD,
    options: ["Monaco", "Vatican City", "San Marino", "Liechtenstein"],
    correctAnswer: "Vatican City",
    explanation: "Vatican City is the smallest sovereign state with an area of just 0.17 square miles."
  },

  // History - Easy
  {
    text: "World War II ended in 1945.",
    type: QuestionType.TRUE_FALSE,
    category: "History",
    difficulty: Difficulty.EASY,
    correctAnswer: "true",
    explanation: "World War II ended in 1945 with Japan's surrender in September."
  },
  {
    text: "Who was the first President of the United States?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "History",
    difficulty: Difficulty.EASY,
    options: ["Thomas Jefferson", "George Washington", "John Adams", "Benjamin Franklin"],
    correctAnswer: "George Washington",
    explanation: "George Washington served as the first President from 1789 to 1797."
  },
  {
    text: "In which year did the Titanic sink?",
    type: QuestionType.TEXT_INPUT,
    category: "History",
    difficulty: Difficulty.EASY,
    correctAnswer: "1912",
    explanation: "The RMS Titanic sank on April 15, 1912, after hitting an iceberg."
  },

  // History - Medium
  {
    text: "The Berlin Wall fell in which year?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "History",
    difficulty: Difficulty.MEDIUM,
    options: ["1987", "1989", "1991", "1993"],
    correctAnswer: "1989",
    explanation: "The Berlin Wall fell on November 9, 1989, marking the end of the Cold War era."
  },
  {
    text: "Napoleon was born in France.",
    type: QuestionType.TRUE_FALSE,
    category: "History",
    difficulty: Difficulty.MEDIUM,
    correctAnswer: "false",
    explanation: "Napoleon was born in Corsica, which had recently been acquired by France."
  },

  // History - Hard
  {
    text: "The Treaty of Versailles was signed in which year?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "History",
    difficulty: Difficulty.HARD,
    options: ["1918", "1919", "1920", "1921"],
    correctAnswer: "1919",
    explanation: "The Treaty of Versailles was signed on June 28, 1919, ending WWI with Germany."
  },

  // Sports - Easy
  {
    text: "How many players are on a basketball team on the court at one time?",
    type: QuestionType.TEXT_INPUT,
    category: "Sports",
    difficulty: Difficulty.EASY,
    correctAnswer: "5",
    explanation: "Each basketball team has 5 players on the court at any given time."
  },
  {
    text: "The Olympics are held every four years.",
    type: QuestionType.TRUE_FALSE,
    category: "Sports",
    difficulty: Difficulty.EASY,
    correctAnswer: "true",
    explanation: "The Summer and Winter Olympics are each held every four years, alternating every two years."
  },
  {
    text: "In which sport would you perform a slam dunk?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "Sports",
    difficulty: Difficulty.EASY,
    options: ["Tennis", "Basketball", "Soccer", "Baseball"],
    correctAnswer: "Basketball",
    explanation: "A slam dunk is a basketball shot where the player jumps and scores by putting the ball directly through the hoop."
  },

  // Sports - Medium
  {
    text: "How many holes are there in a standard round of golf?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "Sports",
    difficulty: Difficulty.MEDIUM,
    options: ["16", "18", "20", "22"],
    correctAnswer: "18",
    explanation: "A standard round of golf consists of 18 holes."
  },
  {
    text: "Tennis was originally called lawn tennis.",
    type: QuestionType.TRUE_FALSE,
    category: "Sports",
    difficulty: Difficulty.MEDIUM,
    correctAnswer: "true",
    explanation: "Tennis was originally called 'lawn tennis' to distinguish it from 'real tennis'."
  },

  // Sports - Hard
  {
    text: "In which year were the first modern Olympic Games held?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "Sports",
    difficulty: Difficulty.HARD,
    options: ["1892", "1896", "1900", "1904"],
    correctAnswer: "1896",
    explanation: "The first modern Olympic Games were held in Athens, Greece in 1896."
  },

  // Entertainment - Easy
  {
    text: "Mickey Mouse was created by Walt Disney.",
    type: QuestionType.TRUE_FALSE,
    category: "Entertainment",
    difficulty: Difficulty.EASY,
    correctAnswer: "true",
    explanation: "Mickey Mouse was created by Walt Disney and first appeared in 1928."
  },
  {
    text: "How many strings does a standard guitar have?",
    type: QuestionType.TEXT_INPUT,
    category: "Entertainment",
    difficulty: Difficulty.EASY,
    correctAnswer: "6",
    explanation: "A standard acoustic or electric guitar has 6 strings."
  },
  {
    text: "Which movie features the song 'Let It Go'?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "Entertainment",
    difficulty: Difficulty.EASY,
    options: ["Moana", "Frozen", "Tangled", "The Little Mermaid"],
    correctAnswer: "Frozen",
    explanation: "'Let It Go' is the signature song from Disney's 2013 animated film Frozen."
  },

  // Entertainment - Medium
  {
    text: "Who directed the movie 'Jaws'?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "Entertainment",
    difficulty: Difficulty.MEDIUM,
    options: ["George Lucas", "Steven Spielberg", "Martin Scorsese", "Francis Ford Coppola"],
    correctAnswer: "Steven Spielberg",
    explanation: "Steven Spielberg directed Jaws in 1975, which became a blockbuster hit."
  },
  {
    text: "The Beatles were from Liverpool, England.",
    type: QuestionType.TRUE_FALSE,
    category: "Entertainment",
    difficulty: Difficulty.MEDIUM,
    correctAnswer: "true",
    explanation: "The Beatles were indeed from Liverpool, England, and formed there in 1960."
  },

  // Entertainment - Hard
  {
    text: "Which film won the Academy Award for Best Picture in 1994?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "Entertainment",
    difficulty: Difficulty.HARD,
    options: ["Forrest Gump", "The Shawshank Redemption", "Pulp Fiction", "The Lion King"],
    correctAnswer: "Forrest Gump",
    explanation: "Forrest Gump won the Academy Award for Best Picture at the 67th Academy Awards in 1995."
  },

  // Technology - Easy
  {
    text: "What does 'WWW' stand for?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "Technology",
    difficulty: Difficulty.EASY,
    options: ["World Wide Web", "World Wide Wait", "World Wide Watch", "World Wide Wire"],
    correctAnswer: "World Wide Web",
    explanation: "WWW stands for World Wide Web, the information system on the Internet."
  },
  {
    text: "A computer mouse was invented before the computer keyboard.",
    type: QuestionType.TRUE_FALSE,
    category: "Technology",
    difficulty: Difficulty.EASY,
    correctAnswer: "false",
    explanation: "The computer keyboard was developed in the 1960s, while the mouse was invented in 1964."
  },

  // Technology - Medium
  {
    text: "What does 'CPU' stand for?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "Technology",
    difficulty: Difficulty.MEDIUM,
    options: ["Central Processing Unit", "Computer Processing Unit", "Central Program Unit", "Computer Program Unit"],
    correctAnswer: "Central Processing Unit",
    explanation: "CPU stands for Central Processing Unit, the main processor of a computer."
  },
  {
    text: "JavaScript and Java are the same programming language.",
    type: QuestionType.TRUE_FALSE,
    category: "Technology",
    difficulty: Difficulty.MEDIUM,
    correctAnswer: "false",
    explanation: "JavaScript and Java are completely different programming languages with different purposes."
  },

  // Technology - Hard
  {
    text: "Who is considered the father of the computer?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "Technology",
    difficulty: Difficulty.HARD,
    options: ["Alan Turing", "Charles Babbage", "John von Neumann", "Ada Lovelace"],
    correctAnswer: "Charles Babbage",
    explanation: "Charles Babbage is considered the father of the computer for his work on the Analytical Engine."
  },

  // Mathematics - Easy
  {
    text: "What is 7 × 8?",
    type: QuestionType.TEXT_INPUT,
    category: "Mathematics",
    difficulty: Difficulty.EASY,
    correctAnswer: "56",
    explanation: "7 multiplied by 8 equals 56."
  },
  {
    text: "Pi is approximately equal to 3.14.",
    type: QuestionType.TRUE_FALSE,
    category: "Mathematics",
    difficulty: Difficulty.EASY,
    correctAnswer: "true",
    explanation: "Pi (π) is approximately 3.14159, commonly rounded to 3.14."
  },

  // Mathematics - Medium
  {
    text: "What is the square root of 144?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "Mathematics",
    difficulty: Difficulty.MEDIUM,
    options: ["10", "11", "12", "13"],
    correctAnswer: "12",
    explanation: "The square root of 144 is 12, because 12 × 12 = 144."
  },
  {
    text: "Zero is a positive number.",
    type: QuestionType.TRUE_FALSE,
    category: "Mathematics",
    difficulty: Difficulty.MEDIUM,
    correctAnswer: "false",
    explanation: "Zero is neither positive nor negative; it is neutral."
  },

  // Mathematics - Hard
  {
    text: "What is the derivative of x²?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "Mathematics",
    difficulty: Difficulty.HARD,
    options: ["x", "2x", "x²", "2x²"],
    correctAnswer: "2x",
    explanation: "Using the power rule, the derivative of x² is 2x."
  },

  // Literature - Easy
  {
    text: "Who wrote 'Romeo and Juliet'?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "Literature",
    difficulty: Difficulty.EASY,
    options: ["Charles Dickens", "William Shakespeare", "Jane Austen", "Mark Twain"],
    correctAnswer: "William Shakespeare",
    explanation: "Romeo and Juliet is a tragedy written by William Shakespeare."
  },
  {
    text: "Harry Potter was written by J.K. Rowling.",
    type: QuestionType.TRUE_FALSE,
    category: "Literature",
    difficulty: Difficulty.EASY,
    correctAnswer: "true",
    explanation: "The Harry Potter series was indeed written by British author J.K. Rowling."
  },

  // Literature - Medium
  {
    text: "In which novel would you find the character Atticus Finch?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "Literature",
    difficulty: Difficulty.MEDIUM,
    options: ["1984", "To Kill a Mockingbird", "The Great Gatsby", "Of Mice and Men"],
    correctAnswer: "To Kill a Mockingbird",
    explanation: "Atticus Finch is a central character in Harper Lee's 'To Kill a Mockingbird'."
  },
  {
    text: "George Orwell wrote '1984' in the year 1984.",
    type: QuestionType.TRUE_FALSE,
    category: "Literature",
    difficulty: Difficulty.MEDIUM,
    correctAnswer: "false",
    explanation: "George Orwell wrote '1984' in 1948; the title refers to a future dystopian society."
  },

  // Literature - Hard
  {
    text: "Who wrote 'One Hundred Years of Solitude'?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "Literature",
    difficulty: Difficulty.HARD,
    options: ["Gabriel García Márquez", "Mario Vargas Llosa", "Jorge Luis Borges", "Pablo Neruda"],
    correctAnswer: "Gabriel García Márquez",
    explanation: "Gabriel García Márquez wrote 'One Hundred Years of Solitude', published in 1967."
  },

  // Art - Easy
  {
    text: "Who painted the Mona Lisa?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "Art",
    difficulty: Difficulty.EASY,
    options: ["Vincent van Gogh", "Pablo Picasso", "Leonardo da Vinci", "Michelangelo"],
    correctAnswer: "Leonardo da Vinci",
    explanation: "The Mona Lisa was painted by Leonardo da Vinci between 1503 and 1519."
  },
  {
    text: "The Statue of Liberty was a gift from France to the United States.",
    type: QuestionType.TRUE_FALSE,
    category: "Art",
    difficulty: Difficulty.EASY,
    correctAnswer: "true",
    explanation: "The Statue of Liberty was indeed a gift from France to the United States in 1886."
  },

  // Art - Medium
  {
    text: "Which artist cut off his own ear?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "Art",
    difficulty: Difficulty.MEDIUM,
    options: ["Pablo Picasso", "Vincent van Gogh", "Claude Monet", "Salvador Dalí"],
    correctAnswer: "Vincent van Gogh",
    explanation: "Vincent van Gogh cut off part of his left ear in 1888 during a mental breakdown."
  },
  {
    text: "The Sistine Chapel ceiling was painted by Michelangelo.",
    type: QuestionType.TRUE_FALSE,
    category: "Art",
    difficulty: Difficulty.MEDIUM,
    correctAnswer: "true",
    explanation: "Michelangelo painted the Sistine Chapel ceiling between 1508 and 1512."
  },

  // Art - Hard
  {
    text: "Which art movement was Pablo Picasso associated with?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "Art",
    difficulty: Difficulty.HARD,
    options: ["Impressionism", "Cubism", "Surrealism", "Abstract Expressionism"],
    correctAnswer: "Cubism",
    explanation: "Pablo Picasso co-founded the Cubist movement with Georges Braque."
  },

  // Music - Easy
  {
    text: "How many keys are on a standard piano?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "Music",
    difficulty: Difficulty.EASY,
    options: ["76", "88", "96", "104"],
    correctAnswer: "88",
    explanation: "A standard piano has 88 keys: 52 white keys and 36 black keys."
  },
  {
    text: "Beethoven was deaf when he composed some of his greatest works.",
    type: QuestionType.TRUE_FALSE,
    category: "Music",
    difficulty: Difficulty.EASY,
    correctAnswer: "true",
    explanation: "Beethoven began losing his hearing in his late twenties and was almost completely deaf by his forties."
  },

  // Music - Medium
  {
    text: "Which instrument did Louis Armstrong famously play?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "Music",
    difficulty: Difficulty.MEDIUM,
    options: ["Saxophone", "Trumpet", "Piano", "Drums"],
    correctAnswer: "Trumpet",
    explanation: "Louis Armstrong was a legendary jazz trumpeter and vocalist."
  },
  {
    text: "Mozart lived to be over 50 years old.",
    type: QuestionType.TRUE_FALSE,
    category: "Music",
    difficulty: Difficulty.MEDIUM,
    correctAnswer: "false",
    explanation: "Mozart died at the young age of 35 in 1791."
  },

  // Music - Hard
  {
    text: "Which composer wrote 'The Four Seasons'?",
    type: QuestionType.MULTIPLE_CHOICE,
    category: "Music",
    difficulty: Difficulty.HARD,
    options: ["Johann Sebastian Bach", "Antonio Vivaldi", "Wolfgang Amadeus Mozart", "Ludwig van Beethoven"],
    correctAnswer: "Antonio Vivaldi",
    explanation: "Antonio Vivaldi composed 'The Four Seasons' around 1720."
  }
];

async function seedQuestions() {
  console.log('🌱 Starting to seed questions...');
  
  try {
    // Clear existing questions
    await prisma.question.deleteMany();
    console.log('🗑️  Cleared existing questions');

    // Calculate point values and insert questions
    const questionsWithPoints = questions.map(q => ({
      ...q,
      pointValue: calculatePointValue(q.difficulty)
    }));

    // Insert questions in batches
    const batchSize = 10;
    for (let i = 0; i < questionsWithPoints.length; i += batchSize) {
      const batch = questionsWithPoints.slice(i, i + batchSize);
      await prisma.question.createMany({
        data: batch
      });
      console.log(`📝 Inserted questions ${i + 1}-${Math.min(i + batchSize, questionsWithPoints.length)}`);
    }

    // Get statistics
    const stats = await prisma.question.groupBy({
      by: ['category', 'difficulty'],
      _count: { id: true }
    });

    console.log('\n📊 Seeding completed! Statistics:');
    console.log(`Total questions: ${questionsWithPoints.length}`);
    
    const categoryStats: Record<string, number> = {};
    const difficultyStats: Record<string, number> = {};
    
    stats.forEach(stat => {
      categoryStats[stat.category] = (categoryStats[stat.category] || 0) + stat._count.id;
      difficultyStats[stat.difficulty] = (difficultyStats[stat.difficulty] || 0) + stat._count.id;
    });

    console.log('\nBy Category:');
    Object.entries(categoryStats).forEach(([category, count]) => {
      console.log(`  ${category}: ${count} questions`);
    });

    console.log('\nBy Difficulty:');
    Object.entries(difficultyStats).forEach(([difficulty, count]) => {
      console.log(`  ${difficulty}: ${count} questions`);
    });

  } catch (error) {
    console.error('❌ Error seeding questions:', error);
    throw error;
  }
}

function calculatePointValue(difficulty: Difficulty): number {
  switch (difficulty) {
    case Difficulty.EASY:
      return 100;
    case Difficulty.MEDIUM:
      return 200;
    case Difficulty.HARD:
      return 300;
    default:
      return 100;
  }
}

// Run seeding if this file is executed directly
if (require.main === module) {
  seedQuestions()
    .then(() => {
      console.log('✅ Seeding completed successfully!');
      process.exit(0);
    })
    .catch((error) => {
      console.error('❌ Seeding failed:', error);
      process.exit(1);
    })
    .finally(async () => {
      await prisma.$disconnect();
    });
}

export { seedQuestions };