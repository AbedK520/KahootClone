import { Socket } from 'socket.io';
import { verifyToken } from '../utils/jwt';
import { JWTPayload } from '../types/auth';

// Extend Socket interface to include user data
declare module 'socket.io' {
  interface Socket {
    user?: JWTPayload;
  }
}

export const socketAuthMiddleware = (socket: Socket, next: (err?: Error) => void) => {
  try {
    const token = socket.handshake.auth.token || socket.handshake.headers.authorization?.split(' ')[1];
    
    if (!token) {
      return next(new Error('Authentication token required'));
    }

    const decoded = verifyToken(token);
    socket.user = decoded;
    next();
  } catch (error) {
    next(new Error('Invalid authentication token'));
  }
};

export const optionalSocketAuth = (socket: Socket, next: (err?: Error) => void) => {
  try {
    const token = socket.handshake.auth.token || socket.handshake.headers.authorization?.split(' ')[1];
    
    if (token) {
      try {
        const decoded = verifyToken(token);
        socket.user = decoded;
      } catch (error) {
        // Token is invalid, but we continue without authentication
        socket.user = undefined;
      }
    }
    
    next();
  } catch (error) {
    next(error instanceof Error ? error : new Error('Unknown error'));
  }
};