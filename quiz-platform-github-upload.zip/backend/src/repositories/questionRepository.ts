import { PrismaClient, QuestionType, Difficulty } from '@prisma/client';
import { CreateQuestionRequest, QuestionFilters } from '../types/question';

const prisma = new PrismaClient();

export class QuestionRepository {
  async create(data: CreateQuestionRequest) {
    const pointValue = this.calculatePointValue(data.difficulty);
    
    return await prisma.question.create({
      data: {
        ...data,
        pointValue
      }
    });
  }

  async findById(id: string) {
    return await prisma.question.findUnique({
      where: { id }
    });
  }

  async findMany(filters: QuestionFilters = {}) {
    const {
      categories,
      difficulties,
      type,
      limit = 50,
      offset = 0
    } = filters;

    return await prisma.question.findMany({
      where: {
        ...(categories && categories.length > 0 && {
          category: { in: categories }
        }),
        ...(difficulties && difficulties.length > 0 && {
          difficulty: { in: difficulties }
        }),
        ...(type && { type })
      },
      skip: offset,
      take: limit,
      orderBy: {
        createdAt: 'desc'
      }
    });
  }

  async findRandomQuestions(filters: QuestionFilters & { count: number }) {
    const {
      categories,
      difficulties,
      type,
      count
    } = filters;

    // First get the total count of matching questions
    const totalCount = await prisma.question.count({
      where: {
        ...(categories && categories.length > 0 && {
          category: { in: categories }
        }),
        ...(difficulties && difficulties.length > 0 && {
          difficulty: { in: difficulties }
        }),
        ...(type && { type })
      }
    });

    if (totalCount === 0) {
      return [];
    }

    // Generate random offsets to get diverse questions
    const randomOffsets = new Set<number>();
    const maxAttempts = Math.min(count * 3, totalCount);
    
    for (let i = 0; i < maxAttempts && randomOffsets.size < count; i++) {
      randomOffsets.add(Math.floor(Math.random() * totalCount));
    }

    const questions = [];
    for (const offset of randomOffsets) {
      const question = await prisma.question.findMany({
        where: {
          ...(categories && categories.length > 0 && {
            category: { in: categories }
          }),
          ...(difficulties && difficulties.length > 0 && {
            difficulty: { in: difficulties }
          }),
          ...(type && { type })
        },
        skip: offset,
        take: 1
      });
      
      if (question.length > 0) {
        questions.push(question[0]);
      }
    }

    return questions.slice(0, count);
  }

  async update(id: string, data: Partial<CreateQuestionRequest>) {
    const updateData: any = { ...data };
    
    // Recalculate point value if difficulty changed
    if (data.difficulty) {
      updateData.pointValue = this.calculatePointValue(data.difficulty);
    }

    return await prisma.question.update({
      where: { id },
      data: updateData
    });
  }

  async delete(id: string) {
    return await prisma.question.delete({
      where: { id }
    });
  }

  async getCategories() {
    const result = await prisma.question.groupBy({
      by: ['category'],
      _count: {
        category: true
      },
      orderBy: {
        category: 'asc'
      }
    });

    return result.map(item => ({
      category: item.category,
      count: item._count.category
    }));
  }

  async getStatistics() {
    const [total, byDifficulty, byType, byCategory] = await Promise.all([
      prisma.question.count(),
      prisma.question.groupBy({
        by: ['difficulty'],
        _count: { difficulty: true }
      }),
      prisma.question.groupBy({
        by: ['type'],
        _count: { type: true }
      }),
      prisma.question.groupBy({
        by: ['category'],
        _count: { category: true }
      })
    ]);

    return {
      total,
      byDifficulty: byDifficulty.reduce((acc, item) => {
        acc[item.difficulty] = item._count.difficulty;
        return acc;
      }, {} as Record<string, number>),
      byType: byType.reduce((acc, item) => {
        acc[item.type] = item._count.type;
        return acc;
      }, {} as Record<string, number>),
      byCategory: byCategory.reduce((acc, item) => {
        acc[item.category] = item._count.category;
        return acc;
      }, {} as Record<string, number>)
    };
  }

  private calculatePointValue(difficulty: Difficulty): number {
    switch (difficulty) {
      case Difficulty.EASY:
        return 100;
      case Difficulty.MEDIUM:
        return 200;
      case Difficulty.HARD:
        return 300;
      default:
        return 100;
    }
  }
}