import { Router, Request, Response } from 'express';
import { AuthService } from '../services/authService';
import { registerSchema, loginSchema, refreshTokenSchema } from '../utils/validation';
import { authenticateToken } from '../middleware/auth';

const router = Router();
const authService = new AuthService();

// Register endpoint
router.post('/register', async (req: Request, res: Response) => {
  try {
    // Validate request body
    const { error, value } = registerSchema.validate(req.body);
    if (error) {
      return res.status(400).json({
        error: {
          code: 'VALIDATION_ERROR',
          message: error.details[0].message,
          timestamp: new Date()
        }
      });
    }

    const result = await authService.register(value);
    
    res.status(201).json({
      success: true,
      data: result
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Registration failed';
    
    res.status(400).json({
      error: {
        code: 'REGISTRATION_FAILED',
        message: errorMessage,
        timestamp: new Date()
      }
    });
  }
});

// Login endpoint
router.post('/login', async (req: Request, res: Response) => {
  try {
    // Validate request body
    const { error, value } = loginSchema.validate(req.body);
    if (error) {
      return res.status(400).json({
        error: {
          code: 'VALIDATION_ERROR',
          message: error.details[0].message,
          timestamp: new Date()
        }
      });
    }

    const result = await authService.login(value);
    
    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Login failed';
    
    res.status(401).json({
      error: {
        code: 'LOGIN_FAILED',
        message: errorMessage,
        timestamp: new Date()
      }
    });
  }
});

// Refresh token endpoint
router.post('/refresh', async (req: Request, res: Response) => {
  try {
    // Validate request body
    const { error, value } = refreshTokenSchema.validate(req.body);
    if (error) {
      return res.status(400).json({
        error: {
          code: 'VALIDATION_ERROR',
          message: error.details[0].message,
          timestamp: new Date()
        }
      });
    }

    const result = await authService.refreshToken(value.refreshToken);
    
    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Token refresh failed';
    
    res.status(401).json({
      error: {
        code: 'TOKEN_REFRESH_FAILED',
        message: errorMessage,
        timestamp: new Date()
      }
    });
  }
});

// Logout endpoint (client-side token removal, server-side could implement token blacklisting)
router.delete('/logout', authenticateToken, async (req: Request, res: Response) => {
  // In a production environment, you might want to blacklist the token
  // For now, we'll just return success as the client will remove the token
  res.json({
    success: true,
    message: 'Logged out successfully'
  });
});

// Get current user endpoint
router.get('/me', authenticateToken, async (req: Request, res: Response) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        error: {
          code: 'UNAUTHORIZED',
          message: 'User not authenticated',
          timestamp: new Date()
        }
      });
    }

    const user = await authService.getUserById(req.user.userId);
    
    res.json({
      success: true,
      data: user
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Failed to get user';
    
    res.status(404).json({
      error: {
        code: 'USER_NOT_FOUND',
        message: errorMessage,
        timestamp: new Date()
      }
    });
  }
});

export default router;