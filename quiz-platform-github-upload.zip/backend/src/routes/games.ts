import { Router, Request, Response } from 'express';
import { authenticateToken } from '../middleware/auth';
import { gameManager } from '../services/gameManager';

const router = Router();

// Get active games (for lobby/matchmaking)
router.get('/active', authenticateToken, async (req: Request, res: Response) => {
  try {
    const activeGames = gameManager.getActiveGames()
      .filter(game => game.status === 'waiting')
      .map(game => ({
        id: game.id,
        mode: game.mode,
        playerCount: game.players.size,
        maxPlayers: game.maxPlayers,
        settings: game.settings,
        createdAt: game.createdAt
      }));

    res.json({
      games: activeGames,
      total: activeGames.length
    });
  } catch (error) {
    console.error('Error fetching active games:', error);
    res.status(500).json({
      error: {
        code: 'FETCH_GAMES_ERROR',
        message: 'Failed to fetch active games',
        timestamp: new Date()
      }
    });
  }
});

// Get game details
router.get('/:gameId', authenticateToken, async (req: Request, res: Response) => {
  try {
    const { gameId } = req.params;
    const game = gameManager.getGameById(gameId);

    if (!game) {
      return res.status(404).json({
        error: {
          code: 'GAME_NOT_FOUND',
          message: 'Game not found',
          timestamp: new Date()
        }
      });
    }

    // Check if user is part of this game
    const userId = req.user?.userId;
    if (!userId || !game.players.has(userId)) {
      return res.status(403).json({
        error: {
          code: 'ACCESS_DENIED',
          message: 'You are not part of this game',
          timestamp: new Date()
        }
      });
    }

    const gameData = {
      id: game.id,
      mode: game.mode,
      status: game.status,
      players: Array.from(game.players.values()).map(player => ({
        id: player.id,
        username: player.username,
        score: player.score,
        isConnected: player.isConnected,
        joinedAt: player.joinedAt
      })),
      maxPlayers: game.maxPlayers,
      currentQuestionIndex: game.currentQuestionIndex,
      totalQuestions: game.questions.length,
      scores: Object.fromEntries(game.scores.entries()),
      settings: game.settings,
      createdAt: game.createdAt
    };

    res.json({ game: gameData });
  } catch (error) {
    console.error('Error fetching game details:', error);
    res.status(500).json({
      error: {
        code: 'FETCH_GAME_ERROR',
        message: 'Failed to fetch game details',
        timestamp: new Date()
      }
    });
  }
});

// Get player's current game
router.get('/player/current', authenticateToken, async (req: Request, res: Response) => {
  try {
    const userId = req.user?.userId;
    if (!userId) {
      return res.status(401).json({
        error: {
          code: 'UNAUTHORIZED',
          message: 'User not authenticated',
          timestamp: new Date()
        }
      });
    }

    const gameId = gameManager.getPlayerCurrentGame(userId);
    if (!gameId) {
      return res.json({ currentGame: null });
    }

    const game = gameManager.getGameById(gameId);
    if (!game) {
      return res.json({ currentGame: null });
    }

    const gameData = {
      id: game.id,
      mode: game.mode,
      status: game.status,
      playerCount: game.players.size,
      maxPlayers: game.maxPlayers,
      currentQuestionIndex: game.currentQuestionIndex,
      totalQuestions: game.questions.length,
      settings: game.settings,
      createdAt: game.createdAt
    };

    res.json({ currentGame: gameData });
  } catch (error) {
    console.error('Error fetching current game:', error);
    res.status(500).json({
      error: {
        code: 'FETCH_CURRENT_GAME_ERROR',
        message: 'Failed to fetch current game',
        timestamp: new Date()
      }
    });
  }
});

// Get game statistics
router.get('/stats/overview', authenticateToken, async (req: Request, res: Response) => {
  try {
    const activeGames = gameManager.getActiveGames();
    
    const stats = {
      totalActiveGames: activeGames.length,
      gamesByMode: activeGames.reduce((acc, game) => {
        acc[game.mode] = (acc[game.mode] || 0) + 1;
        return acc;
      }, {} as Record<string, number>),
      gamesByStatus: activeGames.reduce((acc, game) => {
        acc[game.status] = (acc[game.status] || 0) + 1;
        return acc;
      }, {} as Record<string, number>),
      totalPlayers: activeGames.reduce((total, game) => total + game.players.size, 0)
    };

    res.json({ stats });
  } catch (error) {
    console.error('Error fetching game statistics:', error);
    res.status(500).json({
      error: {
        code: 'FETCH_STATS_ERROR',
        message: 'Failed to fetch game statistics',
        timestamp: new Date()
      }
    });
  }
});

export default router;