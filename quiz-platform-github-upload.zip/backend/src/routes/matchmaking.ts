import { Router, Request, Response } from 'express';
import { authenticateToken } from '../middleware/auth';
import { matchmakingService } from '../services/matchmakingService';

const router = Router();

// Join matchmaking queue
router.post('/join', authenticateToken, async (req: Request, res: Response) => {
  try {
    const { gameMode, preferences } = req.body;
    
    if (!req.user) {
      return res.status(401).json({
        error: {
          code: 'UNAUTHORIZED',
          message: 'User not authenticated',
          timestamp: new Date()
        }
      });
    }

    // Validate request
    if (!gameMode || !preferences) {
      return res.status(400).json({
        error: {
          code: 'INVALID_REQUEST',
          message: 'Game mode and preferences are required',
          timestamp: new Date()
        }
      });
    }

    // Validate game mode
    if (!['quick-match', 'practice'].includes(gameMode)) {
      return res.status(400).json({
        error: {
          code: 'INVALID_GAME_MODE',
          message: 'Invalid game mode. Must be quick-match or practice',
          timestamp: new Date()
        }
      });
    }

    // Set default preferences
    const matchmakingPreferences = {
      maxPlayers: preferences.maxPlayers || 2,
      categories: preferences.categories || [],
      difficulty: preferences.difficulty || [],
      questionCount: preferences.questionCount || 10,
      timePerQuestion: preferences.timePerQuestion || 30
    };

    const result = await matchmakingService.joinMatchmaking({
      playerId: req.user.userId,
      username: req.user.username,
      socketId: '', // Will be set by WebSocket handler
      gameMode,
      preferences: matchmakingPreferences,
      timestamp: new Date()
    });

    if (result.success) {
      res.json({
        success: true,
        data: {
          lobbyId: result.lobbyId,
          gameId: result.gameId,
          message: result.gameId ? 'Game started immediately' : 'Added to matchmaking queue'
        }
      });
    } else {
      res.status(400).json({
        error: {
          code: 'MATCHMAKING_FAILED',
          message: result.error || 'Failed to join matchmaking',
          timestamp: new Date()
        }
      });
    }
  } catch (error) {
    console.error('Error joining matchmaking:', error);
    res.status(500).json({
      error: {
        code: 'INTERNAL_ERROR',
        message: 'Internal server error',
        timestamp: new Date()
      }
    });
  }
});

// Leave matchmaking queue
router.post('/leave', authenticateToken, async (req: Request, res: Response) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        error: {
          code: 'UNAUTHORIZED',
          message: 'User not authenticated',
          timestamp: new Date()
        }
      });
    }

    await matchmakingService.leaveMatchmaking(req.user.userId);

    res.json({
      success: true,
      message: 'Left matchmaking queue'
    });
  } catch (error) {
    console.error('Error leaving matchmaking:', error);
    res.status(500).json({
      error: {
        code: 'INTERNAL_ERROR',
        message: 'Internal server error',
        timestamp: new Date()
      }
    });
  }
});

// Get matchmaking status
router.get('/status', authenticateToken, async (req: Request, res: Response) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        error: {
          code: 'UNAUTHORIZED',
          message: 'User not authenticated',
          timestamp: new Date()
        }
      });
    }

    const status = matchmakingService.getMatchmakingStatus(req.user.userId);

    res.json({
      success: true,
      data: status
    });
  } catch (error) {
    console.error('Error getting matchmaking status:', error);
    res.status(500).json({
      error: {
        code: 'INTERNAL_ERROR',
        message: 'Internal server error',
        timestamp: new Date()
      }
    });
  }
});

// Get active lobbies (for debugging/admin)
router.get('/lobbies', authenticateToken, async (req: Request, res: Response) => {
  try {
    const lobbies = matchmakingService.getActiveLobbies();

    res.json({
      success: true,
      data: {
        lobbies,
        count: lobbies.length
      }
    });
  } catch (error) {
    console.error('Error getting active lobbies:', error);
    res.status(500).json({
      error: {
        code: 'INTERNAL_ERROR',
        message: 'Internal server error',
        timestamp: new Date()
      }
    });
  }
});

// Force start lobby (for testing/admin)
router.post('/lobbies/:lobbyId/start', authenticateToken, async (req: Request, res: Response) => {
  try {
    const { lobbyId } = req.params;

    const result = await matchmakingService.forceStartLobby(lobbyId);

    if (result.success) {
      res.json({
        success: true,
        data: {
          gameId: result.gameId,
          message: 'Lobby started successfully'
        }
      });
    } else {
      res.status(400).json({
        error: {
          code: 'START_LOBBY_FAILED',
          message: result.error || 'Failed to start lobby',
          timestamp: new Date()
        }
      });
    }
  } catch (error) {
    console.error('Error starting lobby:', error);
    res.status(500).json({
      error: {
        code: 'INTERNAL_ERROR',
        message: 'Internal server error',
        timestamp: new Date()
      }
    });
  }
});

export default router;