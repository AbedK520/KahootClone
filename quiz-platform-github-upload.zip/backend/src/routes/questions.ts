import { Router, Request, Response } from 'express';
import Joi from 'joi';
import { QuestionService } from '../services/questionService';
import { authenticateToken, optionalAuth } from '../middleware/auth';
import { QuestionType, Difficulty } from '../types/question';

const router = Router();
const questionService = new QuestionService();

// Validation schemas
const createQuestionSchema = Joi.object({
  text: Joi.string().min(10).max(1000).required().messages({
    'string.min': 'Question text must be at least 10 characters long',
    'string.max': 'Question text must be less than 1000 characters long',
    'any.required': 'Question text is required'
  }),
  type: Joi.string().valid(...Object.values(QuestionType)).required().messages({
    'any.only': 'Question type must be MULTIPLE_CHOICE, TRUE_FALSE, or TEXT_INPUT',
    'any.required': 'Question type is required'
  }),
  category: Joi.string().min(2).max(50).required().messages({
    'string.min': 'Category must be at least 2 characters long',
    'string.max': 'Category must be less than 50 characters long',
    'any.required': 'Category is required'
  }),
  difficulty: Joi.string().valid(...Object.values(Difficulty)).required().messages({
    'any.only': 'Difficulty must be EASY, MEDIUM, or HARD',
    'any.required': 'Difficulty is required'
  }),
  options: Joi.array().items(Joi.string().min(1).max(200)).min(2).max(6).when('type', {
    is: 'MULTIPLE_CHOICE',
    then: Joi.required(),
    otherwise: Joi.optional()
  }).messages({
    'array.min': 'Multiple choice questions must have at least 2 options',
    'array.max': 'Multiple choice questions can have at most 6 options',
    'any.required': 'Options are required for multiple choice questions'
  }),
  correctAnswer: Joi.string().min(1).max(200).required().messages({
    'string.min': 'Correct answer cannot be empty',
    'string.max': 'Correct answer must be less than 200 characters long',
    'any.required': 'Correct answer is required'
  }),
  explanation: Joi.string().max(500).optional().messages({
    'string.max': 'Explanation must be less than 500 characters long'
  })
});

const updateQuestionSchema = Joi.object({
  text: Joi.string().min(10).max(1000).optional(),
  type: Joi.string().valid(...Object.values(QuestionType)).optional(),
  category: Joi.string().min(2).max(50).optional(),
  difficulty: Joi.string().valid(...Object.values(Difficulty)).optional(),
  options: Joi.array().items(Joi.string().min(1).max(200)).min(2).max(6).optional(),
  correctAnswer: Joi.string().min(1).max(200).optional(),
  explanation: Joi.string().max(500).optional()
});

const questionFiltersSchema = Joi.object({
  categories: Joi.alternatives().try(
    Joi.array().items(Joi.string()),
    Joi.string()
  ).optional(),
  difficulties: Joi.alternatives().try(
    Joi.array().items(Joi.string().valid(...Object.values(Difficulty))),
    Joi.string().valid(...Object.values(Difficulty))
  ).optional(),
  type: Joi.string().valid(...Object.values(QuestionType)).optional(),
  limit: Joi.number().integer().min(1).max(100).optional(),
  offset: Joi.number().integer().min(0).optional()
});

// Create question (admin only - for now, any authenticated user can create)
router.post('/', authenticateToken, async (req: Request, res: Response) => {
  try {
    const { error, value } = createQuestionSchema.validate(req.body);
    if (error) {
      return res.status(400).json({
        error: {
          code: 'VALIDATION_ERROR',
          message: error.details[0].message,
          timestamp: new Date()
        }
      });
    }

    const question = await questionService.createQuestion(value);
    
    res.status(201).json({
      success: true,
      data: question
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Failed to create question';
    
    res.status(400).json({
      error: {
        code: 'QUESTION_CREATION_FAILED',
        message: errorMessage,
        timestamp: new Date()
      }
    });
  }
});

// Get questions with filters (public endpoint)
router.get('/', optionalAuth, async (req: Request, res: Response) => {
  try {
    const { error, value } = questionFiltersSchema.validate(req.query);
    if (error) {
      return res.status(400).json({
        error: {
          code: 'VALIDATION_ERROR',
          message: error.details[0].message,
          timestamp: new Date()
        }
      });
    }

    // Convert query string arrays to actual arrays
    const filters = {
      ...value,
      categories: req.query.categories ? (Array.isArray(req.query.categories) ? req.query.categories : [req.query.categories]) : undefined,
      difficulties: req.query.difficulties ? (Array.isArray(req.query.difficulties) ? req.query.difficulties : [req.query.difficulties]) : undefined
    };

    const questions = await questionService.getQuestions(filters);
    
    res.json({
      success: true,
      data: {
        questions,
        pagination: {
          limit: filters.limit || 50,
          offset: filters.offset || 0,
          hasMore: questions.length === (filters.limit || 50)
        }
      }
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Failed to get questions';
    
    res.status(500).json({
      error: {
        code: 'QUESTIONS_FETCH_FAILED',
        message: errorMessage,
        timestamp: new Date()
      }
    });
  }
});

// Get single question by ID
router.get('/:id', optionalAuth, async (req: Request, res: Response) => {
  try {
    const question = await questionService.getQuestion(req.params.id);
    
    if (!question) {
      return res.status(404).json({
        error: {
          code: 'QUESTION_NOT_FOUND',
          message: 'Question not found',
          timestamp: new Date()
        }
      });
    }
    
    res.json({
      success: true,
      data: question
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Failed to get question';
    
    res.status(500).json({
      error: {
        code: 'QUESTION_FETCH_FAILED',
        message: errorMessage,
        timestamp: new Date()
      }
    });
  }
});

// Update question (admin only - for now, any authenticated user can update)
router.put('/:id', authenticateToken, async (req: Request, res: Response) => {
  try {
    const { error, value } = updateQuestionSchema.validate(req.body);
    if (error) {
      return res.status(400).json({
        error: {
          code: 'VALIDATION_ERROR',
          message: error.details[0].message,
          timestamp: new Date()
        }
      });
    }

    const question = await questionService.updateQuestion(req.params.id, value);
    
    res.json({
      success: true,
      data: question
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Failed to update question';
    const statusCode = errorMessage === 'Question not found' ? 404 : 400;
    
    res.status(statusCode).json({
      error: {
        code: 'QUESTION_UPDATE_FAILED',
        message: errorMessage,
        timestamp: new Date()
      }
    });
  }
});

// Delete question (admin only - for now, any authenticated user can delete)
router.delete('/:id', authenticateToken, async (req: Request, res: Response) => {
  try {
    await questionService.deleteQuestion(req.params.id);
    
    res.json({
      success: true,
      message: 'Question deleted successfully'
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Failed to delete question';
    const statusCode = errorMessage === 'Question not found' ? 404 : 400;
    
    res.status(statusCode).json({
      error: {
        code: 'QUESTION_DELETE_FAILED',
        message: errorMessage,
        timestamp: new Date()
      }
    });
  }
});

// Get question categories
router.get('/meta/categories', async (req: Request, res: Response) => {
  try {
    const categories = await questionService.getCategories();
    
    res.json({
      success: true,
      data: categories
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Failed to get categories';
    
    res.status(500).json({
      error: {
        code: 'CATEGORIES_FETCH_FAILED',
        message: errorMessage,
        timestamp: new Date()
      }
    });
  }
});

// Get question statistics
router.get('/meta/statistics', async (req: Request, res: Response) => {
  try {
    const statistics = await questionService.getStatistics();
    
    res.json({
      success: true,
      data: statistics
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Failed to get statistics';
    
    res.status(500).json({
      error: {
        code: 'STATISTICS_FETCH_FAILED',
        message: errorMessage,
        timestamp: new Date()
      }
    });
  }
});

// Get random questions for game (internal endpoint)
router.post('/game/random', authenticateToken, async (req: Request, res: Response) => {
  try {
    const schema = Joi.object({
      count: Joi.number().integer().min(1).max(50).required(),
      categories: Joi.array().items(Joi.string()).optional(),
      difficulties: Joi.array().items(Joi.string().valid(...Object.values(Difficulty))).optional(),
      type: Joi.string().valid(...Object.values(QuestionType)).optional()
    });

    const { error, value } = schema.validate(req.body);
    if (error) {
      return res.status(400).json({
        error: {
          code: 'VALIDATION_ERROR',
          message: error.details[0].message,
          timestamp: new Date()
        }
      });
    }

    const questions = await questionService.getQuestionsForGame(value);
    
    res.json({
      success: true,
      data: questions
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Failed to get random questions';
    
    res.status(500).json({
      error: {
        code: 'RANDOM_QUESTIONS_FAILED',
        message: errorMessage,
        timestamp: new Date()
      }
    });
  }
});

export default router;