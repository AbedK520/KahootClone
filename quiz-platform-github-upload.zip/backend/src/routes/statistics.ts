import { Router, Request, Response } from 'express';
import { authenticateToken } from '../middleware/auth';
import { statisticsService } from '../services/statisticsService';

const router = Router();

// Get player's own statistics
router.get('/player', authenticateToken, async (req: Request, res: Response) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        error: {
          code: 'UNAUTHORIZED',
          message: 'User not authenticated',
          timestamp: new Date()
        }
      });
    }

    const statistics = await statisticsService.getPlayerStatistics(req.user.userId);

    res.json({
      success: true,
      data: statistics
    });
  } catch (error) {
    console.error('Error getting player statistics:', error);
    res.status(500).json({
      error: {
        code: 'INTERNAL_ERROR',
        message: 'Failed to retrieve player statistics',
        timestamp: new Date()
      }
    });
  }
});

// Get specific player's statistics (public)
router.get('/player/:userId', async (req: Request, res: Response) => {
  try {
    const { userId } = req.params;

    const statistics = await statisticsService.getPlayerStatistics(userId);

    // Return public version of statistics (remove sensitive data)
    const publicStats = {
      userId: statistics.userId,
      username: statistics.username,
      gamesPlayed: statistics.gamesPlayed,
      averageScore: statistics.averageScore,
      accuracyRate: statistics.accuracyRate,
      rank: statistics.rank,
      percentile: statistics.percentile,
      categoryPerformance: statistics.categoryPerformance,
      difficultyPerformance: statistics.difficultyPerformance
    };

    res.json({
      success: true,
      data: publicStats
    });
  } catch (error) {
    console.error('Error getting player statistics:', error);
    res.status(500).json({
      error: {
        code: 'INTERNAL_ERROR',
        message: 'Failed to retrieve player statistics',
        timestamp: new Date()
      }
    });
  }
});

// Get global leaderboard
router.get('/leaderboard', async (req: Request, res: Response) => {
  try {
    const limit = parseInt(req.query.limit as string) || 50;
    const sortBy = (req.query.sortBy as string) || 'totalScore';

    // Validate sortBy parameter
    const validSortOptions = ['totalScore', 'averageScore', 'accuracyRate', 'gamesPlayed'];
    if (!validSortOptions.includes(sortBy)) {
      return res.status(400).json({
        error: {
          code: 'INVALID_SORT_OPTION',
          message: 'Invalid sort option. Must be one of: ' + validSortOptions.join(', '),
          timestamp: new Date()
        }
      });
    }

    const leaderboard = await statisticsService.getGlobalLeaderboard(
      Math.min(limit, 100), // Cap at 100
      sortBy as any
    );

    res.json({
      success: true,
      data: {
        leaderboard,
        sortBy,
        limit: leaderboard.length
      }
    });
  } catch (error) {
    console.error('Error getting leaderboard:', error);
    res.status(500).json({
      error: {
        code: 'INTERNAL_ERROR',
        message: 'Failed to retrieve leaderboard',
        timestamp: new Date()
      }
    });
  }
});

// Get category-specific leaderboard
router.get('/leaderboard/category/:category', async (req: Request, res: Response) => {
  try {
    const { category } = req.params;
    const limit = parseInt(req.query.limit as string) || 20;

    const leaderboard = await statisticsService.getCategoryLeaderboard(
      category,
      Math.min(limit, 50) // Cap at 50
    );

    res.json({
      success: true,
      data: {
        leaderboard,
        category,
        limit: leaderboard.length
      }
    });
  } catch (error) {
    console.error('Error getting category leaderboard:', error);
    res.status(500).json({
      error: {
        code: 'INTERNAL_ERROR',
        message: 'Failed to retrieve category leaderboard',
        timestamp: new Date()
      }
    });
  }
});

// Get global statistics
router.get('/global', async (req: Request, res: Response) => {
  try {
    const globalStats = await statisticsService.getGlobalStatistics();

    res.json({
      success: true,
      data: globalStats
    });
  } catch (error) {
    console.error('Error getting global statistics:', error);
    res.status(500).json({
      error: {
        code: 'INTERNAL_ERROR',
        message: 'Failed to retrieve global statistics',
        timestamp: new Date()
      }
    });
  }
});

// Update player statistics (internal endpoint, typically called after games)
router.post('/player/:userId/update', authenticateToken, async (req: Request, res: Response) => {
  try {
    const { userId } = req.params;
    const { gameSessionId, score, accuracy, questionsAnswered, totalTimeSpent } = req.body;

    // Validate that the authenticated user matches the userId or is an admin
    if (req.user?.userId !== userId) {
      return res.status(403).json({
        error: {
          code: 'FORBIDDEN',
          message: 'Cannot update statistics for another user',
          timestamp: new Date()
        }
      });
    }

    // Validate required fields
    if (!gameSessionId || score === undefined || accuracy === undefined || !questionsAnswered) {
      return res.status(400).json({
        error: {
          code: 'MISSING_FIELDS',
          message: 'gameSessionId, score, accuracy, and questionsAnswered are required',
          timestamp: new Date()
        }
      });
    }

    await statisticsService.updatePlayerStatistics(
      userId,
      gameSessionId,
      score,
      accuracy,
      questionsAnswered,
      totalTimeSpent || 0
    );

    res.json({
      success: true,
      message: 'Player statistics updated successfully'
    });
  } catch (error) {
    console.error('Error updating player statistics:', error);
    res.status(500).json({
      error: {
        code: 'INTERNAL_ERROR',
        message: 'Failed to update player statistics',
        timestamp: new Date()
      }
    });
  }
});

export default router;