import { Router, Request, Response } from 'express';
import Joi from 'joi';
import { UserService } from '../services/userService';
import { authenticateToken } from '../middleware/auth';

const router = Router();
const userService = new UserService();

// Validation schemas
const updateProfileSchema = Joi.object({
  username: Joi.string()
    .alphanum()
    .min(3)
    .max(30)
    .optional()
    .messages({
      'string.alphanum': 'Username must contain only alphanumeric characters',
      'string.min': 'Username must be at least 3 characters long',
      'string.max': 'Username must be less than 30 characters long'
    }),
  email: Joi.string()
    .email()
    .optional()
    .messages({
      'string.email': 'Please provide a valid email address'
    })
});

// Get current user profile
router.get('/profile', authenticateToken, async (req: Request, res: Response) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        error: {
          code: 'UNAUTHORIZED',
          message: 'User not authenticated',
          timestamp: new Date()
        }
      });
    }

    const profile = await userService.getUserProfile(req.user.userId);
    
    res.json({
      success: true,
      data: profile
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Failed to get profile';
    
    res.status(404).json({
      error: {
        code: 'PROFILE_NOT_FOUND',
        message: errorMessage,
        timestamp: new Date()
      }
    });
  }
});

// Update user profile
router.put('/profile', authenticateToken, async (req: Request, res: Response) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        error: {
          code: 'UNAUTHORIZED',
          message: 'User not authenticated',
          timestamp: new Date()
        }
      });
    }

    // Validate request body
    const { error, value } = updateProfileSchema.validate(req.body);
    if (error) {
      return res.status(400).json({
        error: {
          code: 'VALIDATION_ERROR',
          message: error.details[0].message,
          timestamp: new Date()
        }
      });
    }

    const updatedProfile = await userService.updateUserProfile(req.user.userId, value);
    
    res.json({
      success: true,
      data: updatedProfile
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Failed to update profile';
    
    res.status(400).json({
      error: {
        code: 'PROFILE_UPDATE_FAILED',
        message: errorMessage,
        timestamp: new Date()
      }
    });
  }
});

// Get user statistics
router.get('/stats', authenticateToken, async (req: Request, res: Response) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        error: {
          code: 'UNAUTHORIZED',
          message: 'User not authenticated',
          timestamp: new Date()
        }
      });
    }

    const stats = await userService.getUserStats(req.user.userId);
    
    res.json({
      success: true,
      data: stats
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Failed to get statistics';
    
    res.status(404).json({
      error: {
        code: 'STATS_NOT_FOUND',
        message: errorMessage,
        timestamp: new Date()
      }
    });
  }
});

// Get leaderboard (all users ranked by score)
router.get('/leaderboard', async (req: Request, res: Response) => {
  try {
    const limit = parseInt(req.query.limit as string) || 50;
    const offset = parseInt(req.query.offset as string) || 0;

    if (limit > 100) {
      return res.status(400).json({
        error: {
          code: 'INVALID_LIMIT',
          message: 'Limit cannot exceed 100',
          timestamp: new Date()
        }
      });
    }

    const users = await userService.getAllUsers(limit, offset);
    
    res.json({
      success: true,
      data: {
        users,
        pagination: {
          limit,
          offset,
          hasMore: users.length === limit
        }
      }
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Failed to get leaderboard';
    
    res.status(500).json({
      error: {
        code: 'LEADERBOARD_ERROR',
        message: errorMessage,
        timestamp: new Date()
      }
    });
  }
});

// Search users
router.get('/search', async (req: Request, res: Response) => {
  try {
    const query = req.query.q as string;
    const limit = parseInt(req.query.limit as string) || 20;

    if (!query || query.trim().length < 2) {
      return res.status(400).json({
        error: {
          code: 'INVALID_QUERY',
          message: 'Search query must be at least 2 characters long',
          timestamp: new Date()
        }
      });
    }

    const users = await userService.searchUsers(query.trim(), limit);
    
    res.json({
      success: true,
      data: users
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Failed to search users';
    
    res.status(500).json({
      error: {
        code: 'SEARCH_ERROR',
        message: errorMessage,
        timestamp: new Date()
      }
    });
  }
});

export default router;