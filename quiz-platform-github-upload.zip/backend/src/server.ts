import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { createServer } from 'http';
import { Server } from 'socket.io';
import dotenv from 'dotenv';
import authRoutes from './routes/auth';
import userRoutes from './routes/users';
import questionRoutes from './routes/questions';
import gameRoutes from './routes/games';
import matchmakingRoutes from './routes/matchmaking';
import statisticsRoutes from './routes/statistics';
import { socketAuthMiddleware } from './middleware/socketAuth';
import { gameManager } from './services/gameManager';
import { connectionManager } from './services/connectionManager';
import { resilienceManager } from './services/resilienceManager';
import { errorHandler } from './services/errorHandler';
import { matchmakingService } from './services/matchmakingService';
import { ServerToClientEvents, ClientToServerEvents, InterServerEvents, SocketData } from './types/socket';

// Load environment variables
dotenv.config();

const app = express();
const server = createServer(app);
const io = new Server<ClientToServerEvents, ServerToClientEvents, InterServerEvents, SocketData>(server, {
  cors: {
    origin: process.env.NODE_ENV === 'production' 
      ? process.env.FRONTEND_URL 
      : "http://localhost:3000",
    methods: ["GET", "POST"],
    credentials: true
  },
  pingTimeout: 60000,
  pingInterval: 25000,
  transports: ['websocket', 'polling']
});

// Initialize managers with socket server
gameManager.setSocketServer(io);
connectionManager.setSocketServer(io);

// Middleware
app.use(helmet());
app.use(cors({
  origin: process.env.NODE_ENV === 'production' 
    ? process.env.FRONTEND_URL 
    : "http://localhost:3000",
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Health check endpoint with connection stats
app.get('/health', (req, res) => {
  const connectionStats = connectionManager.getConnectionStats();
  res.json({ 
    status: 'OK', 
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV,
    connections: {
      total: connectionStats.totalConnections,
      uniqueUsers: connectionStats.uniqueUsers
    },
    games: {
      active: gameManager.getActiveGames().length
    }
  });
});

// API routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/questions', questionRoutes);
app.use('/api/games', gameRoutes);
app.use('/api/matchmaking', matchmakingRoutes);
app.use('/api/statistics', statisticsRoutes);

// API routes placeholder for other endpoints
app.use('/api', (req, res) => {
  res.json({ message: 'Quiz Platform API - Additional routes will be implemented' });
});

// WebSocket authentication middleware
io.use(socketAuthMiddleware);

// WebSocket connection handling
io.on('connection', (socket) => {
  console.log(`User ${socket.user?.username} connected:`, socket.id);
  
  // Add connection to manager
  connectionManager.addConnection(socket);

  // Handle game creation
  socket.on('create-game', async (data, callback) => {
    try {
      connectionManager.updateActivity(socket);
      const result = await gameManager.createGame(socket, data);
      callback(result);
    } catch (error) {
      errorHandler.handleSocketError(socket, error, 'create-game');
      callback({ success: false, error: 'Internal server error' });
    }
  });

  // Handle joining games
  socket.on('join-game', async (data, callback) => {
    try {
      connectionManager.updateActivity(socket);
      const result = await gameManager.joinGame(socket, data);
      if (result.success) {
        connectionManager.setUserGameId(socket, data.gameId);
      }
      callback(result);
    } catch (error) {
      errorHandler.handleSocketError(socket, error, 'join-game');
      callback({ success: false, error: 'Internal server error' });
    }
  });

  // Handle game start
  socket.on('start-game', async (data, callback) => {
    try {
      connectionManager.updateActivity(socket);
      const result = await gameManager.startGame(socket, data.gameId);
      callback(result);
    } catch (error) {
      errorHandler.handleSocketError(socket, error, 'start-game');
      callback({ success: false, error: 'Internal server error' });
    }
  });

  // Handle answer submission
  socket.on('submit-answer', async (data) => {
    try {
      connectionManager.updateActivity(socket);
      await gameManager.submitAnswer(socket, data);
    } catch (error) {
      console.error('Error in submit-answer:', error);
      socket.emit('error', { code: 'SUBMIT_ERROR', message: 'Failed to submit answer' });
    }
  });

  // Handle leaving games
  socket.on('leave-game', async (data) => {
    try {
      connectionManager.updateActivity(socket);
      await gameManager.leaveGame(socket, data);
      connectionManager.setUserGameId(socket, undefined);
    } catch (error) {
      console.error('Error in leave-game:', error);
    }
  });

  // Handle game reconnection
  socket.on('reconnect-game', async (data, callback) => {
    try {
      connectionManager.updateActivity(socket);
      const result = await resilienceManager.handleReconnectionAttempt(socket, data.gameId);
      if (result.success) {
        connectionManager.setUserGameId(socket, data.gameId);
      }
      callback(result);
    } catch (error) {
      errorHandler.handleSocketError(socket, error, 'reconnect-game');
      callback({ success: false, error: 'Internal server error' });
    }
  });

  // Handle disconnection
  socket.on('disconnect', async (reason) => {
    console.log(`User ${socket.user?.username} disconnected:`, socket.id, 'Reason:', reason);
    
    try {
      // Get current game before handling disconnection
      const gameId = gameManager.getPlayerCurrentGame(socket.user?.userId || '');
      
      // Handle resilience protocols
      if (gameId) {
        resilienceManager.handlePlayerDisconnection(socket, gameId);
      }
      
      // Handle game disconnection
      await gameManager.handleDisconnect(socket);
      
      // Remove connection from manager
      connectionManager.removeConnection(socket);
    } catch (error) {
      errorHandler.handleSocketError(socket, error, 'disconnect');
    }
  });

  // Handle connection errors
  socket.on('error', (error) => {
    errorHandler.handleSocketError(socket, error, 'socket-connection');
  });
});

// Start cleanup tasks
connectionManager.startCleanupTask();
matchmakingService.startCleanupTask();

// Graceful shutdown handling
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully...');
  await Promise.all([
    connectionManager.shutdown(),
    resilienceManager.shutdown()
  ]);
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});

process.on('SIGINT', async () => {
  console.log('SIGINT received, shutting down gracefully...');
  await Promise.all([
    connectionManager.shutdown(),
    resilienceManager.shutdown()
  ]);
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});

const PORT = process.env.PORT || 3001;

server.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`📊 Environment: ${process.env.NODE_ENV}`);
  console.log(`🔗 WebSocket server ready with authentication`);
  console.log(`🎮 Game manager initialized`);
  console.log(`📡 Connection manager started`);
});