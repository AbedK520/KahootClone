import { Server, Socket } from 'socket.io';
import { gameManager } from './gameManager';

interface ConnectionInfo {
  userId: string;
  username: string;
  connectedAt: Date;
  lastActivity: Date;
  gameId?: string;
}

class ConnectionManager {
  private connections: Map<string, ConnectionInfo> = new Map(); // socketId -> ConnectionInfo
  private userSockets: Map<string, Set<string>> = new Map(); // userId -> Set of socketIds
  private io: Server | null = null;

  public setSocketServer(io: Server) {
    this.io = io;
  }

  public addConnection(socket: Socket): void {
    if (!socket.user) return;

    const connectionInfo: ConnectionInfo = {
      userId: socket.user.userId,
      username: socket.user.username,
      connectedAt: new Date(),
      lastActivity: new Date()
    };

    this.connections.set(socket.id, connectionInfo);

    // Track user's sockets
    if (!this.userSockets.has(socket.user.userId)) {
      this.userSockets.set(socket.user.userId, new Set());
    }
    this.userSockets.get(socket.user.userId)!.add(socket.id);

    console.log(`User ${socket.user.username} connected with socket ${socket.id}`);
    this.logConnectionStats();
  }

  public removeConnection(socket: Socket): void {
    const connectionInfo = this.connections.get(socket.id);
    if (!connectionInfo) return;

    // Remove from connections
    this.connections.delete(socket.id);

    // Remove from user sockets
    const userSocketSet = this.userSockets.get(connectionInfo.userId);
    if (userSocketSet) {
      userSocketSet.delete(socket.id);
      if (userSocketSet.size === 0) {
        this.userSockets.delete(connectionInfo.userId);
      }
    }

    console.log(`User ${connectionInfo.username} disconnected from socket ${socket.id}`);
    this.logConnectionStats();
  }

  public updateActivity(socket: Socket): void {
    const connectionInfo = this.connections.get(socket.id);
    if (connectionInfo) {
      connectionInfo.lastActivity = new Date();
    }
  }

  public setUserGameId(socket: Socket, gameId: string | undefined): void {
    const connectionInfo = this.connections.get(socket.id);
    if (connectionInfo) {
      connectionInfo.gameId = gameId;
    }
  }

  public getUserConnections(userId: string): string[] {
    const socketSet = this.userSockets.get(userId);
    return socketSet ? Array.from(socketSet) : [];
  }

  public isUserConnected(userId: string): boolean {
    return this.userSockets.has(userId) && this.userSockets.get(userId)!.size > 0;
  }

  public getConnectionInfo(socketId: string): ConnectionInfo | undefined {
    return this.connections.get(socketId);
  }

  public getTotalConnections(): number {
    return this.connections.size;
  }

  public getUniqueUsers(): number {
    return this.userSockets.size;
  }

  public getConnectionsByGame(): Map<string, number> {
    const gameConnections = new Map<string, number>();
    
    for (const connection of this.connections.values()) {
      if (connection.gameId) {
        const count = gameConnections.get(connection.gameId) || 0;
        gameConnections.set(connection.gameId, count + 1);
      }
    }
    
    return gameConnections;
  }

  public cleanupInactiveConnections(): void {
    const now = new Date();
    const inactivityThreshold = 30 * 60 * 1000; // 30 minutes
    const connectionsToRemove: string[] = [];

    for (const [socketId, connectionInfo] of this.connections.entries()) {
      const timeSinceActivity = now.getTime() - connectionInfo.lastActivity.getTime();
      
      if (timeSinceActivity > inactivityThreshold) {
        connectionsToRemove.push(socketId);
      }
    }

    for (const socketId of connectionsToRemove) {
      const socket = this.io?.sockets.sockets.get(socketId);
      if (socket) {
        console.log(`Disconnecting inactive socket: ${socketId}`);
        socket.disconnect(true);
      }
    }

    if (connectionsToRemove.length > 0) {
      console.log(`Cleaned up ${connectionsToRemove.length} inactive connections`);
    }
  }

  public getConnectionStats(): {
    totalConnections: number;
    uniqueUsers: number;
    gameConnections: Map<string, number>;
    averageConnectionTime: number;
  } {
    const now = new Date();
    let totalConnectionTime = 0;

    for (const connection of this.connections.values()) {
      totalConnectionTime += now.getTime() - connection.connectedAt.getTime();
    }

    const averageConnectionTime = this.connections.size > 0 
      ? totalConnectionTime / this.connections.size 
      : 0;

    return {
      totalConnections: this.getTotalConnections(),
      uniqueUsers: this.getUniqueUsers(),
      gameConnections: this.getConnectionsByGame(),
      averageConnectionTime
    };
  }

  private logConnectionStats(): void {
    const stats = this.getConnectionStats();
    console.log(`Connection Stats - Total: ${stats.totalConnections}, Unique Users: ${stats.uniqueUsers}`);
  }

  // Periodic cleanup task
  public startCleanupTask(): void {
    setInterval(() => {
      this.cleanupInactiveConnections();
    }, 10 * 60 * 1000); // Run every 10 minutes
  }

  // Graceful shutdown
  public async shutdown(): Promise<void> {
    console.log('Shutting down connection manager...');
    
    // Disconnect all sockets
    if (this.io) {
      this.io.disconnectSockets(true);
    }

    // Clear all data structures
    this.connections.clear();
    this.userSockets.clear();
    
    console.log('Connection manager shutdown complete');
  }
}

export const connectionManager = new ConnectionManager();