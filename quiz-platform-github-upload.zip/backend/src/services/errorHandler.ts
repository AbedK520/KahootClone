import { Socket } from 'socket.io';

export interface GameError {
  code: string;
  message: string;
  gameId?: string;
  playerId?: string;
  timestamp: Date;
  severity: 'low' | 'medium' | 'high' | 'critical';
}

export class ErrorHandler {
  private errorLog: GameError[] = [];
  private maxLogSize = 1000;

  public logError(error: GameError): void {
    this.errorLog.push(error);
    
    // Keep log size manageable
    if (this.errorLog.length > this.maxLogSize) {
      this.errorLog = this.errorLog.slice(-this.maxLogSize);
    }

    // Log to console based on severity
    const logMessage = `[${error.severity.toUpperCase()}] ${error.code}: ${error.message}`;
    
    switch (error.severity) {
      case 'critical':
        console.error(logMessage, error);
        break;
      case 'high':
        console.error(logMessage);
        break;
      case 'medium':
        console.warn(logMessage);
        break;
      case 'low':
        console.log(logMessage);
        break;
    }
  }

  public handleSocketError(socket: Socket, error: any, context: string): void {
    const gameError: GameError = {
      code: 'SOCKET_ERROR',
      message: `Socket error in ${context}: ${error.message || error}`,
      playerId: socket.user?.userId,
      timestamp: new Date(),
      severity: 'medium'
    };

    this.logError(gameError);

    // Send error to client
    socket.emit('error', {
      code: gameError.code,
      message: 'A network error occurred. Please try again.',
      timestamp: gameError.timestamp
    });
  }

  public handleGameError(gameId: string, playerId: string | undefined, error: any, context: string): void {
    const gameError: GameError = {
      code: 'GAME_ERROR',
      message: `Game error in ${context}: ${error.message || error}`,
      gameId,
      playerId,
      timestamp: new Date(),
      severity: 'high'
    };

    this.logError(gameError);
  }

  public handleConnectionError(playerId: string, error: any, context: string): void {
    const gameError: GameError = {
      code: 'CONNECTION_ERROR',
      message: `Connection error in ${context}: ${error.message || error}`,
      playerId,
      timestamp: new Date(),
      severity: 'medium'
    };

    this.logError(gameError);
  }

  public handleCriticalError(error: any, context: string): void {
    const gameError: GameError = {
      code: 'CRITICAL_ERROR',
      message: `Critical system error in ${context}: ${error.message || error}`,
      timestamp: new Date(),
      severity: 'critical'
    };

    this.logError(gameError);
  }

  public getRecentErrors(limit: number = 50): GameError[] {
    return this.errorLog.slice(-limit);
  }

  public getErrorsByGame(gameId: string): GameError[] {
    return this.errorLog.filter(error => error.gameId === gameId);
  }

  public getErrorsByPlayer(playerId: string): GameError[] {
    return this.errorLog.filter(error => error.playerId === playerId);
  }

  public getErrorStats(): {
    total: number;
    bySeverity: Record<string, number>;
    byCode: Record<string, number>;
    recentCount: number;
  } {
    const now = new Date();
    const oneHourAgo = new Date(now.getTime() - 60 * 60 * 1000);
    
    const recentErrors = this.errorLog.filter(error => error.timestamp > oneHourAgo);
    
    const bySeverity = this.errorLog.reduce((acc, error) => {
      acc[error.severity] = (acc[error.severity] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const byCode = this.errorLog.reduce((acc, error) => {
      acc[error.code] = (acc[error.code] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return {
      total: this.errorLog.length,
      bySeverity,
      byCode,
      recentCount: recentErrors.length
    };
  }

  public clearOldErrors(): void {
    const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    this.errorLog = this.errorLog.filter(error => error.timestamp > oneWeekAgo);
  }
}

export const errorHandler = new ErrorHandler();