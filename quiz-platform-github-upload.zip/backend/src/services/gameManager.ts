import { Server, Socket } from 'socket.io';
import { v4 as uuidv4 } from 'uuid';
import { GameSession, Player, CreateGameData, JoinGameData, SubmitAnswerData, QuestionPresentedData, RoundCompleteData, GameCompleteData } from '../types/socket';
import { questionService } from './questionService';
import { scoringService, PlayerPerformanceMetrics } from './scoringService';
import { Difficulty } from '../types/question';

class GameManager {
  private games: Map<string, GameSession> = new Map();
  private playerGameMap: Map<string, string> = new Map(); // playerId -> gameId
  private io: Server | null = null;

  public setSocketServer(io: Server) {
    this.io = io;
  }

  public async createGame(socket: Socket, data: CreateGameData): Promise<{ success: boolean; gameId?: string; error?: string }> {
    try {
      if (!socket.user) {
        return { success: false, error: 'Authentication required' };
      }

      const gameId = uuidv4();
      const questions = await questionService.getQuestionsForGame(
        data.settings.questionCount,
        data.settings.categories,
        data.settings.difficulty
      );

      if (questions.length < data.settings.questionCount) {
        return { success: false, error: 'Not enough questions available for the selected criteria' };
      }

      const game: GameSession = {
        id: gameId,
        mode: data.mode,
        status: 'waiting',
        players: new Map(),
        maxPlayers: data.maxPlayers,
        questions,
        currentQuestionIndex: -1,
        scores: new Map(),
        answers: new Map(),
        createdAt: new Date(),
        settings: data.settings
      };

      this.games.set(gameId, game);

      // Join the creator to the game
      await this.joinGame(socket, { gameId, playerId: socket.user.userId });

      return { success: true, gameId };
    } catch (error) {
      console.error('Error creating game:', error);
      return { success: false, error: 'Failed to create game' };
    }
  }

  public async joinGame(socket: Socket, data: JoinGameData): Promise<{ success: boolean; error?: string }> {
    try {
      if (!socket.user) {
        return { success: false, error: 'Authentication required' };
      }

      const game = this.games.get(data.gameId);
      if (!game) {
        return { success: false, error: 'Game not found' };
      }

      if (game.status !== 'waiting') {
        return { success: false, error: 'Game is not accepting new players' };
      }

      if (game.players.size >= game.maxPlayers) {
        return { success: false, error: 'Game is full' };
      }

      // Remove player from any existing game
      const existingGameId = this.playerGameMap.get(socket.user.userId);
      if (existingGameId && existingGameId !== data.gameId) {
        await this.leaveGame(socket, { gameId: existingGameId });
      }

      const player: Player = {
        id: socket.user.userId,
        username: socket.user.username,
        socketId: socket.id,
        score: 0,
        isConnected: true,
        joinedAt: new Date(),
        metrics: scoringService.createInitialMetrics(),
        currentStreak: 0
      };

      game.players.set(socket.user.userId, player);
      game.scores.set(socket.user.userId, 0);
      this.playerGameMap.set(socket.user.userId, data.gameId);

      // Join socket room
      await socket.join(data.gameId);

      // Notify all players in the game
      this.io?.to(data.gameId).emit('player-joined', {
        playerId: socket.user.userId,
        username: socket.user.username,
        playerCount: game.players.size
      });

      // Send game state to the joining player
      this.io?.to(socket.id).emit('game-state-sync', {
        gameId: data.gameId,
        state: this.getGameStateForClient(game)
      });

      return { success: true };
    } catch (error) {
      console.error('Error joining game:', error);
      return { success: false, error: 'Failed to join game' };
    }
  }

  public async startGame(socket: Socket, gameId: string): Promise<{ success: boolean; error?: string }> {
    try {
      if (!socket.user) {
        return { success: false, error: 'Authentication required' };
      }

      const game = this.games.get(gameId);
      if (!game) {
        return { success: false, error: 'Game not found' };
      }

      if (game.status !== 'waiting') {
        return { success: false, error: 'Game cannot be started' };
      }

      if (game.players.size < 1) {
        return { success: false, error: 'Not enough players to start the game' };
      }

      game.status = 'in-progress';
      game.currentQuestionIndex = 0;
      game.currentQuestionStartTime = new Date();

      // Initialize answers map for the first question
      game.answers.set('0', new Map());

      const firstQuestion = this.getQuestionForClient(game.questions[0], 0, game.settings.timePerQuestion);
      
      this.io?.to(gameId).emit('game-started', {
        gameId,
        firstQuestion
      });

      // Set timeout for the first question
      this.scheduleQuestionTimeout(gameId, 0);

      return { success: true };
    } catch (error) {
      console.error('Error starting game:', error);
      return { success: false, error: 'Failed to start game' };
    }
  }

  public async submitAnswer(socket: Socket, data: SubmitAnswerData): Promise<void> {
    try {
      if (!socket.user) {
        return;
      }

      const game = this.games.get(data.gameId);
      if (!game || game.status !== 'in-progress') {
        return;
      }

      if (data.questionIndex !== game.currentQuestionIndex) {
        return; // Answer for wrong question
      }

      const questionAnswers = game.answers.get(data.questionIndex.toString());
      if (!questionAnswers) {
        return;
      }

      // Check if player already answered this question
      if (questionAnswers.has(socket.user.userId)) {
        return;
      }

      // Record the answer
      questionAnswers.set(socket.user.userId, {
        answer: data.answer,
        timestamp: data.timestamp
      });

      // Check if all players have answered
      const connectedPlayers = Array.from(game.players.values()).filter(p => p.isConnected);
      if (questionAnswers.size >= connectedPlayers.length) {
        await this.processRoundComplete(data.gameId, data.questionIndex);
      }
    } catch (error) {
      console.error('Error submitting answer:', error);
    }
  }

  public async leaveGame(socket: Socket, data: { gameId: string }): Promise<void> {
    try {
      if (!socket.user) {
        return;
      }

      const game = this.games.get(data.gameId);
      if (!game) {
        return;
      }

      const player = game.players.get(socket.user.userId);
      if (!player) {
        return;
      }

      // Mark player as disconnected
      player.isConnected = false;
      this.playerGameMap.delete(socket.user.userId);

      // Leave socket room
      await socket.leave(data.gameId);

      // Notify other players
      this.io?.to(data.gameId).emit('player-disconnected', {
        playerId: socket.user.userId,
        username: socket.user.username,
        playerCount: Array.from(game.players.values()).filter(p => p.isConnected).length
      });

      // If no connected players remain, clean up the game
      const connectedPlayers = Array.from(game.players.values()).filter(p => p.isConnected);
      if (connectedPlayers.length === 0) {
        this.games.delete(data.gameId);
      }
    } catch (error) {
      console.error('Error leaving game:', error);
    }
  }

  public async handleDisconnect(socket: Socket): Promise<void> {
    try {
      if (!socket.user) {
        return;
      }

      const gameId = this.playerGameMap.get(socket.user.userId);
      if (gameId) {
        await this.leaveGame(socket, { gameId });
      }
    } catch (error) {
      console.error('Error handling disconnect:', error);
    }
  }

  public async reconnectToGame(socket: Socket, gameId: string): Promise<{ success: boolean; gameState?: Partial<GameSession>; error?: string }> {
    try {
      if (!socket.user) {
        return { success: false, error: 'Authentication required' };
      }

      const game = this.games.get(gameId);
      if (!game) {
        return { success: false, error: 'Game not found' };
      }

      const player = game.players.get(socket.user.userId);
      if (!player) {
        return { success: false, error: 'Player not in this game' };
      }

      // Update player connection status
      player.isConnected = true;
      player.socketId = socket.id;
      this.playerGameMap.set(socket.user.userId, gameId);

      // Join socket room
      await socket.join(gameId);

      // Send current game state
      const gameState = this.getGameStateForClient(game);
      
      this.io?.to(socket.id).emit('reconnected', {
        gameId,
        currentState: gameState
      });

      return { success: true, gameState };
    } catch (error) {
      console.error('Error reconnecting to game:', error);
      return { success: false, error: 'Failed to reconnect' };
    }
  }

  private async processRoundComplete(gameId: string, questionIndex: number): Promise<void> {
    const game = this.games.get(gameId);
    if (!game) return;

    const question = game.questions[questionIndex];
    const questionAnswers = game.answers.get(questionIndex.toString());
    if (!questionAnswers) return;

    const roundResults: Record<string, any> = {};
    const scoreUpdates: Record<string, number> = {};

    // Calculate scores for this round using the scoring service
    for (const [playerId, answerData] of questionAnswers.entries()) {
      const player = game.players.get(playerId);
      if (!player) continue;

      const isCorrect = answerData.answer.toLowerCase().trim() === question.correctAnswer.toLowerCase().trim();
      const responseTime = game.currentQuestionStartTime 
        ? answerData.timestamp.getTime() - game.currentQuestionStartTime.getTime()
        : game.settings.timePerQuestion * 1000;

      // Update streak
      if (isCorrect) {
        player.currentStreak += 1;
      } else {
        player.currentStreak = 0;
      }

      // Calculate score using scoring service
      const scoreBreakdown = scoringService.calculateQuestionScore({
        questionDifficulty: question.difficulty as Difficulty,
        isCorrect,
        responseTime,
        timeLimit: game.settings.timePerQuestion * 1000,
        questionPointValue: question.pointValue,
        playerStreak: player.currentStreak,
        totalQuestionsAnswered: player.metrics.questionsAnswered + 1,
        correctAnswersInSession: player.metrics.correctAnswers + (isCorrect ? 1 : 0)
      });

      // Update player metrics
      player.metrics = scoringService.updatePlayerMetrics(
        player.metrics,
        question.category,
        question.difficulty as Difficulty,
        isCorrect,
        responseTime,
        scoreBreakdown.totalPoints
      );

      // Update total score
      const newScore = player.score + scoreBreakdown.totalPoints;
      game.scores.set(playerId, newScore);
      player.score = newScore;
      scoreUpdates[playerId] = newScore;

      roundResults[playerId] = {
        answer: answerData.answer,
        isCorrect,
        points: scoreBreakdown.totalPoints,
        scoreBreakdown: {
          basePoints: scoreBreakdown.basePoints,
          speedBonus: scoreBreakdown.speedBonus,
          accuracyBonus: scoreBreakdown.accuracyBonus,
          streakBonus: scoreBreakdown.streakBonus,
          difficultyMultiplier: scoreBreakdown.difficultyMultiplier,
          totalPoints: scoreBreakdown.totalPoints
        },
        responseTime,
        streak: player.currentStreak
      };
    }

    // Send round complete event
    const roundCompleteData: RoundCompleteData = {
      questionIndex,
      correctAnswer: question.correctAnswer,
      scores: scoreUpdates,
      playerAnswers: roundResults
    };

    this.io?.to(gameId).emit('round-complete', roundCompleteData);

    // Check if game is complete
    if (questionIndex >= game.questions.length - 1) {
      await this.completeGame(gameId);
    } else {
      // Move to next question after a delay
      setTimeout(() => {
        this.presentNextQuestion(gameId);
      }, 3000); // 3 second delay between questions
    }
  }

  private async presentNextQuestion(gameId: string): Promise<void> {
    const game = this.games.get(gameId);
    if (!game) return;

    game.currentQuestionIndex++;
    game.currentQuestionStartTime = new Date();

    // Initialize answers map for the next question
    game.answers.set(game.currentQuestionIndex.toString(), new Map());

    const nextQuestion = this.getQuestionForClient(game.questions[game.currentQuestionIndex], game.currentQuestionIndex, game.settings.timePerQuestion);
    
    this.io?.to(gameId).emit('question-presented', nextQuestion);

    // Set timeout for this question
    this.scheduleQuestionTimeout(gameId, game.currentQuestionIndex);
  }

  private async completeGame(gameId: string): Promise<void> {
    const game = this.games.get(gameId);
    if (!game) return;

    game.status = 'completed';

    // Calculate final scores with end-game bonuses
    const finalPlayerData = Array.from(game.players.values()).map(player => {
      const finalScoring = scoringService.calculateFinalGameScore(
        player.score,
        player.metrics,
        game.mode
      );
      
      const performanceGrade = scoringService.getPerformanceGrade(player.metrics);
      
      return {
        playerId: player.id,
        username: player.username,
        baseScore: player.score,
        finalScore: finalScoring.finalScore,
        bonuses: finalScoring.bonuses,
        metrics: player.metrics,
        grade: performanceGrade,
        rank: 0
      };
    });

    // Sort by final score and assign ranks
    const rankings = finalPlayerData
      .sort((a, b) => b.finalScore - a.finalScore)
      .map((player, index) => ({ ...player, rank: index + 1 }));

    // Update final scores in the game
    for (const playerData of rankings) {
      game.scores.set(playerData.playerId, playerData.finalScore);
      const player = game.players.get(playerData.playerId);
      if (player) {
        player.score = playerData.finalScore;
      }
    }

    const gameCompleteData: GameCompleteData = {
      finalScores: Object.fromEntries(game.scores.entries()),
      rankings: rankings.map(r => ({
        playerId: r.playerId,
        username: r.username,
        score: r.finalScore,
        rank: r.rank
      })),
      statistics: {
        totalQuestions: game.questions.length,
        gameMode: game.mode,
        duration: Date.now() - game.createdAt.getTime()
      }
    };

    this.io?.to(gameId).emit('game-complete', gameCompleteData);

    // Send detailed results to each player
    for (const playerData of rankings) {
      const player = game.players.get(playerData.playerId);
      if (player && player.isConnected) {
        this.io?.to(player.socketId).emit('detailed-results', {
          gameId,
          playerResults: {
            baseScore: playerData.baseScore,
            finalScore: playerData.finalScore,
            bonuses: playerData.bonuses,
            metrics: playerData.metrics,
            grade: playerData.grade,
            rank: playerData.rank,
            totalPlayers: rankings.length
          }
        });
      }
    }

    // Clean up game after a delay
    setTimeout(() => {
      this.games.delete(gameId);
      // Clean up player mappings
      for (const player of game.players.values()) {
        this.playerGameMap.delete(player.id);
      }
    }, 30000); // Keep game data for 30 seconds after completion
  }

  private scheduleQuestionTimeout(gameId: string, questionIndex: number): void {
    const game = this.games.get(gameId);
    if (!game) return;

    setTimeout(async () => {
      const currentGame = this.games.get(gameId);
      if (!currentGame || currentGame.currentQuestionIndex !== questionIndex) {
        return; // Game ended or moved to next question
      }

      // Force round completion even if not all players answered
      await this.processRoundComplete(gameId, questionIndex);
    }, game.settings.timePerQuestion * 1000);
  }

  private getQuestionForClient(question: any, questionIndex: number, timeLimit: number): QuestionPresentedData {
    return {
      question: {
        id: question.id,
        text: question.text,
        type: question.type,
        category: question.category,
        difficulty: question.difficulty,
        options: question.options,
        pointValue: question.pointValue,
        explanation: question.explanation,
        createdAt: new Date()
      },
      questionIndex,
      timeLimit,
      startTime: new Date()
    };
  }

  private getGameStateForClient(game: GameSession): Partial<GameSession> {
    return {
      id: game.id,
      mode: game.mode,
      status: game.status,
      maxPlayers: game.maxPlayers,
      currentQuestionIndex: game.currentQuestionIndex,
      settings: game.settings,
      // Convert Map to object for JSON serialization
      players: Object.fromEntries(
        Array.from(game.players.entries()).map(([id, player]) => [id, {
          ...player,
          // Don't send socket IDs to clients
          socketId: undefined
        }])
      ) as any,
      scores: Object.fromEntries(game.scores.entries()) as any
    };
  }

  private getBasePointsForDifficulty(difficulty: string): number {
    switch (difficulty.toLowerCase()) {
      case 'easy': return 10;
      case 'medium': return 20;
      case 'hard': return 30;
      default: return 15;
    }
  }

  public getGameById(gameId: string): GameSession | undefined {
    return this.games.get(gameId);
  }

  public getActiveGames(): GameSession[] {
    return Array.from(this.games.values());
  }

  public getPlayerCurrentGame(playerId: string): string | undefined {
    return this.playerGameMap.get(playerId);
  }
}

export const gameManager = new GameManager();