import { v4 as uuidv4 } from 'uuid';
import { gameManager } from './gameManager';

interface MatchmakingRequest {
  playerId: string;
  username: string;
  socketId: string;
  gameMode: 'quick-match' | 'practice';
  preferences: {
    maxPlayers: number;
    categories?: string[];
    difficulty?: string[];
    questionCount: number;
    timePerQuestion: number;
  };
  timestamp: Date;
}

interface WaitingLobby {
  id: string;
  gameMode: 'quick-match' | 'practice';
  maxPlayers: number;
  currentPlayers: string[];
  preferences: {
    categories?: string[];
    difficulty?: string[];
    questionCount: number;
    timePerQuestion: number;
  };
  createdAt: Date;
}

class MatchmakingService {
  private waitingPlayers: Map<string, MatchmakingRequest> = new Map();
  private waitingLobbies: Map<string, WaitingLobby> = new Map();
  private playerLobbyMap: Map<string, string> = new Map(); // playerId -> lobbyId

  /**
   * Add player to matchmaking queue
   */
  public async joinMatchmaking(request: MatchmakingRequest): Promise<{
    success: boolean;
    lobbyId?: string;
    gameId?: string;
    error?: string;
  }> {
    try {
      // Remove player from any existing matchmaking
      await this.leaveMatchmaking(request.playerId);

      // For practice mode, create immediate single-player game
      if (request.gameMode === 'practice') {
        return await this.createPracticeGame(request);
      }

      // For quick match, try to find existing lobby or create new one
      const existingLobby = this.findCompatibleLobby(request);
      
      if (existingLobby) {
        return await this.joinExistingLobby(request, existingLobby);
      } else {
        return await this.createNewLobby(request);
      }
    } catch (error) {
      console.error('Error in matchmaking:', error);
      return { success: false, error: 'Matchmaking failed' };
    }
  }

  /**
   * Remove player from matchmaking
   */
  public async leaveMatchmaking(playerId: string): Promise<void> {
    try {
      // Remove from waiting players
      this.waitingPlayers.delete(playerId);

      // Remove from lobby if in one
      const lobbyId = this.playerLobbyMap.get(playerId);
      if (lobbyId) {
        const lobby = this.waitingLobbies.get(lobbyId);
        if (lobby) {
          lobby.currentPlayers = lobby.currentPlayers.filter(id => id !== playerId);
          
          // If lobby is empty, remove it
          if (lobby.currentPlayers.length === 0) {
            this.waitingLobbies.delete(lobbyId);
          }
        }
        this.playerLobbyMap.delete(playerId);
      }
    } catch (error) {
      console.error('Error leaving matchmaking:', error);
    }
  }

  /**
   * Get current matchmaking status for a player
   */
  public getMatchmakingStatus(playerId: string): {
    inQueue: boolean;
    lobbyId?: string;
    playersInLobby?: number;
    maxPlayers?: number;
  } {
    const lobbyId = this.playerLobbyMap.get(playerId);
    const isWaiting = this.waitingPlayers.has(playerId);

    if (lobbyId) {
      const lobby = this.waitingLobbies.get(lobbyId);
      return {
        inQueue: true,
        lobbyId,
        playersInLobby: lobby?.currentPlayers.length || 0,
        maxPlayers: lobby?.maxPlayers || 0
      };
    }

    return {
      inQueue: isWaiting,
      lobbyId: undefined,
      playersInLobby: 0,
      maxPlayers: 0
    };
  }

  /**
   * Get all active lobbies (for admin/debugging)
   */
  public getActiveLobbies(): WaitingLobby[] {
    return Array.from(this.waitingLobbies.values());
  }

  /**
   * Force start a lobby (for testing or admin purposes)
   */
  public async forceStartLobby(lobbyId: string): Promise<{
    success: boolean;
    gameId?: string;
    error?: string;
  }> {
    const lobby = this.waitingLobbies.get(lobbyId);
    if (!lobby) {
      return { success: false, error: 'Lobby not found' };
    }

    if (lobby.currentPlayers.length === 0) {
      return { success: false, error: 'No players in lobby' };
    }

    return await this.startGameFromLobby(lobby);
  }

  private async createPracticeGame(request: MatchmakingRequest): Promise<{
    success: boolean;
    gameId?: string;
    error?: string;
  }> {
    try {
      // Create a mock socket object for practice games
      const mockSocket = {
        user: {
          userId: request.playerId,
          username: request.username,
          email: '' // Not needed for practice
        },
        id: request.socketId
      } as any;

      // Create game through game manager
      const result = await gameManager.createGame(mockSocket, {
        mode: 'practice',
        maxPlayers: 1,
        settings: {
          questionCount: request.preferences.questionCount,
          timePerQuestion: request.preferences.timePerQuestion,
          categories: request.preferences.categories || [],
          difficulty: request.preferences.difficulty || []
        }
      });

      return result;
    } catch (error) {
      console.error('Error creating practice game:', error);
      return {
        success: false,
        error: 'Failed to create practice game'
      };
    }
  }

  private findCompatibleLobby(request: MatchmakingRequest): WaitingLobby | null {
    for (const lobby of this.waitingLobbies.values()) {
      // Check if lobby has space
      if (lobby.currentPlayers.length >= lobby.maxPlayers) {
        continue;
      }

      // Check if game mode matches
      if (lobby.gameMode !== request.gameMode) {
        continue;
      }

      // Check if preferences are compatible
      if (!this.arePreferencesCompatible(lobby.preferences, request.preferences)) {
        continue;
      }

      return lobby;
    }

    return null;
  }

  private arePreferencesCompatible(
    lobbyPrefs: WaitingLobby['preferences'],
    requestPrefs: MatchmakingRequest['preferences']
  ): boolean {
    // For now, use simple compatibility check
    // In a more advanced system, this could be more sophisticated
    
    return (
      lobbyPrefs.questionCount === requestPrefs.questionCount &&
      lobbyPrefs.timePerQuestion === requestPrefs.timePerQuestion
    );
  }

  private async joinExistingLobby(
    request: MatchmakingRequest,
    lobby: WaitingLobby
  ): Promise<{
    success: boolean;
    lobbyId?: string;
    gameId?: string;
    error?: string;
  }> {
    // Add player to lobby
    lobby.currentPlayers.push(request.playerId);
    this.waitingPlayers.set(request.playerId, request);
    this.playerLobbyMap.set(request.playerId, lobby.id);

    // Check if lobby is full and ready to start
    if (lobby.currentPlayers.length >= lobby.maxPlayers) {
      return await this.startGameFromLobby(lobby);
    }

    return {
      success: true,
      lobbyId: lobby.id
    };
  }

  private async createNewLobby(request: MatchmakingRequest): Promise<{
    success: boolean;
    lobbyId?: string;
    error?: string;
  }> {
    const lobbyId = uuidv4();
    
    const lobby: WaitingLobby = {
      id: lobbyId,
      gameMode: request.gameMode,
      maxPlayers: request.preferences.maxPlayers,
      currentPlayers: [request.playerId],
      preferences: {
        categories: request.preferences.categories,
        difficulty: request.preferences.difficulty,
        questionCount: request.preferences.questionCount,
        timePerQuestion: request.preferences.timePerQuestion
      },
      createdAt: new Date()
    };

    this.waitingLobbies.set(lobbyId, lobby);
    this.waitingPlayers.set(request.playerId, request);
    this.playerLobbyMap.set(request.playerId, lobbyId);

    // For single player games, start immediately
    if (request.preferences.maxPlayers === 1) {
      return await this.startGameFromLobby(lobby);
    }

    return {
      success: true,
      lobbyId
    };
  }

  private async startGameFromLobby(lobby: WaitingLobby): Promise<{
    success: boolean;
    gameId?: string;
    error?: string;
  }> {
    try {
      // Get the first player to create the game (lobby creator)
      const firstPlayerId = lobby.currentPlayers[0];
      const firstPlayerRequest = this.waitingPlayers.get(firstPlayerId);
      
      if (!firstPlayerRequest) {
        return { success: false, error: 'Player not found' };
      }

      // Create a mock socket object for the game creator
      const mockSocket = {
        user: {
          userId: firstPlayerRequest.playerId,
          username: firstPlayerRequest.username,
          email: '' // Not needed for game creation
        },
        id: firstPlayerRequest.socketId
      } as any;

      // Create game through game manager
      const result = await gameManager.createGame(mockSocket, {
        mode: lobby.gameMode === 'quick-match' ? 'quick-match' : 'practice',
        maxPlayers: lobby.maxPlayers,
        settings: {
          questionCount: lobby.preferences.questionCount,
          timePerQuestion: lobby.preferences.timePerQuestion,
          categories: lobby.preferences.categories || [],
          difficulty: lobby.preferences.difficulty || []
        }
      });

      if (result.success && result.gameId) {
        // Add other players to the game if it's multiplayer
        if (lobby.currentPlayers.length > 1) {
          for (let i = 1; i < lobby.currentPlayers.length; i++) {
            const playerId = lobby.currentPlayers[i];
            const playerRequest = this.waitingPlayers.get(playerId);
            
            if (playerRequest) {
              const playerSocket = {
                user: {
                  userId: playerRequest.playerId,
                  username: playerRequest.username,
                  email: ''
                },
                id: playerRequest.socketId
              } as any;

              // Join the existing game
              await gameManager.joinGame(playerSocket, {
                gameId: result.gameId,
                playerId: playerRequest.playerId
              });
            }
          }
        }

        // Clean up lobby
        this.waitingLobbies.delete(lobby.id);
        for (const playerId of lobby.currentPlayers) {
          this.waitingPlayers.delete(playerId);
          this.playerLobbyMap.delete(playerId);
        }

        return {
          success: true,
          gameId: result.gameId
        };
      } else {
        return {
          success: false,
          error: result.error || 'Failed to create game'
        };
      }
    } catch (error) {
      console.error('Error starting game from lobby:', error);
      return { success: false, error: 'Failed to start game' };
    }
  }

  /**
   * Cleanup expired lobbies and requests
   */
  public cleanupExpired(): void {
    const now = new Date();
    const maxWaitTime = 5 * 60 * 1000; // 5 minutes

    // Clean up expired lobbies
    const expiredLobbies: string[] = [];
    for (const [lobbyId, lobby] of this.waitingLobbies.entries()) {
      if (now.getTime() - lobby.createdAt.getTime() > maxWaitTime) {
        expiredLobbies.push(lobbyId);
      }
    }

    for (const lobbyId of expiredLobbies) {
      const lobby = this.waitingLobbies.get(lobbyId);
      if (lobby) {
        // Remove all players from this lobby
        for (const playerId of lobby.currentPlayers) {
          this.waitingPlayers.delete(playerId);
          this.playerLobbyMap.delete(playerId);
        }
        this.waitingLobbies.delete(lobbyId);
      }
    }

    // Clean up expired individual requests
    const expiredRequests: string[] = [];
    for (const [playerId, request] of this.waitingPlayers.entries()) {
      if (now.getTime() - request.timestamp.getTime() > maxWaitTime) {
        expiredRequests.push(playerId);
      }
    }

    for (const playerId of expiredRequests) {
      this.leaveMatchmaking(playerId);
    }

    if (expiredLobbies.length > 0 || expiredRequests.length > 0) {
      console.log(`Cleaned up ${expiredLobbies.length} expired lobbies and ${expiredRequests.length} expired requests`);
    }
  }

  /**
   * Start periodic cleanup
   */
  public startCleanupTask(): void {
    setInterval(() => {
      this.cleanupExpired();
    }, 60 * 1000); // Run every minute
  }
}

export const matchmakingService = new MatchmakingService();