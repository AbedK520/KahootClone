import { QuestionRepository } from '../repositories/questionRepository';
import { CreateQuestionRequest, QuestionFilters, QuestionResponse, QuestionForGame } from '../types/question';

export class QuestionService {
  private questionRepository: QuestionRepository;

  constructor() {
    this.questionRepository = new QuestionRepository();
  }

  async createQuestion(data: CreateQuestionRequest): Promise<QuestionResponse> {
    // Validate question data
    this.validateQuestionData(data);

    const question = await this.questionRepository.create(data);
    return this.formatQuestionResponse(question);
  }

  async getQuestion(id: string): Promise<QuestionResponse | null> {
    const question = await this.questionRepository.findById(id);
    return question ? this.formatQuestionResponse(question) : null;
  }

  async getQuestions(filters: QuestionFilters): Promise<QuestionResponse[]> {
    const questions = await this.questionRepository.findMany(filters);
    return questions.map(q => this.formatQuestionResponse(q));
  }

  async getQuestionsForGame(count: number, categories?: string[], difficulties?: string[]): Promise<any[]> {
    const filters: QuestionFilters & { count: number } = {
      count,
      categories,
      difficulties: difficulties as any // Type assertion for now, will be properly typed later
    };
    
    const questions = await this.questionRepository.findRandomQuestions(filters);
    return questions.map(q => ({
      id: q.id,
      text: q.text,
      type: q.type,
      category: q.category,
      difficulty: q.difficulty,
      options: q.options,
      correctAnswer: q.correctAnswer,
      pointValue: q.pointValue
    }));
  }

  async updateQuestion(id: string, data: Partial<CreateQuestionRequest>): Promise<QuestionResponse> {
    const existingQuestion = await this.questionRepository.findById(id);
    if (!existingQuestion) {
      throw new Error('Question not found');
    }

    if (data.text || data.type || data.options || data.correctAnswer) {
      this.validateQuestionData({ ...existingQuestion, ...data } as CreateQuestionRequest);
    }

    const updatedQuestion = await this.questionRepository.update(id, data);
    return this.formatQuestionResponse(updatedQuestion);
  }

  async deleteQuestion(id: string): Promise<void> {
    const existingQuestion = await this.questionRepository.findById(id);
    if (!existingQuestion) {
      throw new Error('Question not found');
    }

    await this.questionRepository.delete(id);
  }

  async getCategories() {
    return await this.questionRepository.getCategories();
  }

  async getStatistics() {
    return await this.questionRepository.getStatistics();
  }

  async validateGameQuestions(questionIds: string[]): Promise<boolean> {
    // Check if all questions exist and are valid for game use
    const questions = await Promise.all(
      questionIds.map(id => this.questionRepository.findById(id))
    );

    return questions.every(q => q !== null);
  }

  private validateQuestionData(data: CreateQuestionRequest): void {
    if (!data.text || data.text.trim().length === 0) {
      throw new Error('Question text is required');
    }

    if (!data.correctAnswer || data.correctAnswer.trim().length === 0) {
      throw new Error('Correct answer is required');
    }

    if (!data.category || data.category.trim().length === 0) {
      throw new Error('Category is required');
    }

    // Validate multiple choice questions have options
    if (data.type === 'MULTIPLE_CHOICE') {
      if (!data.options || data.options.length < 2) {
        throw new Error('Multiple choice questions must have at least 2 options');
      }

      if (!data.options.includes(data.correctAnswer)) {
        throw new Error('Correct answer must be one of the provided options');
      }
    }

    // Validate true/false questions
    if (data.type === 'TRUE_FALSE') {
      const validAnswers = ['true', 'false', 'True', 'False', 'TRUE', 'FALSE'];
      if (!validAnswers.includes(data.correctAnswer)) {
        throw new Error('True/False questions must have "true" or "false" as the correct answer');
      }
    }
  }

  private formatQuestionResponse(question: any): QuestionResponse {
    return {
      id: question.id,
      text: question.text,
      type: question.type,
      category: question.category,
      difficulty: question.difficulty,
      options: question.options,
      explanation: question.explanation,
      pointValue: question.pointValue,
      createdAt: question.createdAt
    };
  }

  private formatQuestionForGame(question: any): QuestionForGame {
    return {
      id: question.id,
      text: question.text,
      type: question.type,
      category: question.category,
      difficulty: question.difficulty,
      options: question.options,
      pointValue: question.pointValue
    };
  }
}

export const questionService = new QuestionService();