import { Socket } from 'socket.io';
import { gameManager } from './gameManager';
import { connectionManager } from './connectionManager';
import { errorHandler } from './errorHandler';

interface ReconnectionAttempt {
  playerId: string;
  gameId: string;
  attempts: number;
  lastAttempt: Date;
  maxAttempts: number;
}

interface PlayerTimeout {
  playerId: string;
  gameId: string;
  timeoutId: NodeJS.Timeout;
  startTime: Date;
  timeoutDuration: number;
}

export class ResilienceManager {
  private reconnectionAttempts: Map<string, ReconnectionAttempt> = new Map();
  private playerTimeouts: Map<string, PlayerTimeout> = new Map();
  private gameStateBackups: Map<string, any> = new Map();
  
  private readonly MAX_RECONNECTION_ATTEMPTS = 5;
  private readonly RECONNECTION_WINDOW = 5 * 60 * 1000; // 5 minutes
  private readonly PLAYER_TIMEOUT_DURATION = 60 * 1000; // 1 minute
  private readonly BACKUP_CLEANUP_INTERVAL = 10 * 60 * 1000; // 10 minutes

  constructor() {
    // Start periodic cleanup
    setInterval(() => {
      this.cleanupExpiredReconnections();
      this.cleanupOldBackups();
    }, this.BACKUP_CLEANUP_INTERVAL);
  }

  public handlePlayerDisconnection(socket: Socket, gameId: string): void {
    if (!socket.user) return;

    const playerId = socket.user.userId;
    
    try {
      // Create backup of current game state
      this.createGameStateBackup(gameId);

      // Set up reconnection tracking
      this.setupReconnectionTracking(playerId, gameId);

      // Start player timeout
      this.startPlayerTimeout(playerId, gameId);

      console.log(`Player ${socket.user.username} disconnected from game ${gameId}, starting resilience protocols`);
    } catch (error) {
      errorHandler.handleConnectionError(playerId, error, 'handlePlayerDisconnection');
    }
  }

  public async handleReconnectionAttempt(socket: Socket, gameId: string): Promise<{ success: boolean; error?: string; gameState?: any }> {
    if (!socket.user) {
      return { success: false, error: 'Authentication required' };
    }

    const playerId = socket.user.userId;
    const attemptKey = `${playerId}-${gameId}`;

    try {
      // Check if reconnection is allowed
      const reconnectionData = this.reconnectionAttempts.get(attemptKey);
      if (!reconnectionData) {
        return { success: false, error: 'No active game session found' };
      }

      if (reconnectionData.attempts >= reconnectionData.maxAttempts) {
        return { success: false, error: 'Maximum reconnection attempts exceeded' };
      }

      // Check if reconnection window is still valid
      const now = new Date();
      const timeSinceLastAttempt = now.getTime() - reconnectionData.lastAttempt.getTime();
      if (timeSinceLastAttempt > this.RECONNECTION_WINDOW) {
        this.reconnectionAttempts.delete(attemptKey);
        return { success: false, error: 'Reconnection window expired' };
      }

      // Update reconnection attempt
      reconnectionData.attempts++;
      reconnectionData.lastAttempt = now;

      // Clear player timeout
      this.clearPlayerTimeout(playerId);

      // Attempt to reconnect to game
      const reconnectionResult = await gameManager.reconnectToGame(socket, gameId);
      
      if (reconnectionResult.success) {
        // Successful reconnection
        this.reconnectionAttempts.delete(attemptKey);
        
        // Restore game state if needed
        const backupState = this.gameStateBackups.get(gameId);
        
        console.log(`Player ${socket.user.username} successfully reconnected to game ${gameId}`);
        
        return {
          success: true,
          gameState: reconnectionResult.gameState || backupState
        };
      } else {
        return {
          success: false,
          error: reconnectionResult.error || 'Reconnection failed'
        };
      }
    } catch (error) {
      errorHandler.handleConnectionError(playerId, error, 'handleReconnectionAttempt');
      return { success: false, error: 'Internal error during reconnection' };
    }
  }

  public handlePlayerTimeout(playerId: string, gameId: string): void {
    try {
      const game = gameManager.getGameById(gameId);
      if (!game) return;

      const player = game.players.get(playerId);
      if (!player) return;

      console.log(`Player ${player.username} timed out in game ${gameId}`);

      // Mark player as disconnected but keep them in the game
      player.isConnected = false;

      // If game is in progress, handle the timeout gracefully
      if (game.status === 'in-progress') {
        // Auto-submit empty answer for current question if applicable
        const currentQuestionAnswers = game.answers.get(game.currentQuestionIndex.toString());
        if (currentQuestionAnswers && !currentQuestionAnswers.has(playerId)) {
          currentQuestionAnswers.set(playerId, {
            answer: '', // Empty answer for timeout
            timestamp: new Date()
          });
        }
      }

      // Clean up timeout tracking
      this.playerTimeouts.delete(playerId);

      errorHandler.logError({
        code: 'PLAYER_TIMEOUT',
        message: `Player ${player.username} timed out in game ${gameId}`,
        gameId,
        playerId,
        timestamp: new Date(),
        severity: 'medium'
      });
    } catch (error) {
      errorHandler.handleGameError(gameId, playerId, error, 'handlePlayerTimeout');
    }
  }

  public clearPlayerTimeout(playerId: string): void {
    const timeout = this.playerTimeouts.get(playerId);
    if (timeout) {
      clearTimeout(timeout.timeoutId);
      this.playerTimeouts.delete(playerId);
    }
  }

  public createGameStateBackup(gameId: string): void {
    try {
      const game = gameManager.getGameById(gameId);
      if (!game) return;

      // Create a backup of critical game state
      const backup = {
        id: game.id,
        mode: game.mode,
        status: game.status,
        currentQuestionIndex: game.currentQuestionIndex,
        currentQuestionStartTime: game.currentQuestionStartTime,
        scores: Object.fromEntries(game.scores.entries()),
        answers: Object.fromEntries(
          Array.from(game.answers.entries()).map(([key, value]) => [
            key,
            Object.fromEntries(value.entries())
          ])
        ),
        players: Object.fromEntries(
          Array.from(game.players.entries()).map(([id, player]) => [id, {
            id: player.id,
            username: player.username,
            score: player.score,
            isConnected: player.isConnected,
            joinedAt: player.joinedAt
          }])
        ),
        settings: game.settings,
        backupTimestamp: new Date()
      };

      this.gameStateBackups.set(gameId, backup);
    } catch (error) {
      errorHandler.handleGameError(gameId, undefined, error, 'createGameStateBackup');
    }
  }

  public getGameStateBackup(gameId: string): any {
    return this.gameStateBackups.get(gameId);
  }

  private setupReconnectionTracking(playerId: string, gameId: string): void {
    const attemptKey = `${playerId}-${gameId}`;
    
    this.reconnectionAttempts.set(attemptKey, {
      playerId,
      gameId,
      attempts: 0,
      lastAttempt: new Date(),
      maxAttempts: this.MAX_RECONNECTION_ATTEMPTS
    });
  }

  private startPlayerTimeout(playerId: string, gameId: string): void {
    // Clear any existing timeout
    this.clearPlayerTimeout(playerId);

    const timeoutId = setTimeout(() => {
      this.handlePlayerTimeout(playerId, gameId);
    }, this.PLAYER_TIMEOUT_DURATION);

    this.playerTimeouts.set(playerId, {
      playerId,
      gameId,
      timeoutId,
      startTime: new Date(),
      timeoutDuration: this.PLAYER_TIMEOUT_DURATION
    });
  }

  private cleanupExpiredReconnections(): void {
    const now = new Date();
    const expiredKeys: string[] = [];

    for (const [key, attempt] of this.reconnectionAttempts.entries()) {
      const timeSinceLastAttempt = now.getTime() - attempt.lastAttempt.getTime();
      if (timeSinceLastAttempt > this.RECONNECTION_WINDOW) {
        expiredKeys.push(key);
      }
    }

    for (const key of expiredKeys) {
      this.reconnectionAttempts.delete(key);
    }

    if (expiredKeys.length > 0) {
      console.log(`Cleaned up ${expiredKeys.length} expired reconnection attempts`);
    }
  }

  private cleanupOldBackups(): void {
    const now = new Date();
    const maxBackupAge = 30 * 60 * 1000; // 30 minutes
    const expiredGameIds: string[] = [];

    for (const [gameId, backup] of this.gameStateBackups.entries()) {
      const backupAge = now.getTime() - backup.backupTimestamp.getTime();
      if (backupAge > maxBackupAge) {
        expiredGameIds.push(gameId);
      }
    }

    for (const gameId of expiredGameIds) {
      this.gameStateBackups.delete(gameId);
    }

    if (expiredGameIds.length > 0) {
      console.log(`Cleaned up ${expiredGameIds.length} old game state backups`);
    }
  }

  public getResilienceStats(): {
    activeReconnections: number;
    activeTimeouts: number;
    backupCount: number;
    totalReconnectionAttempts: number;
  } {
    const totalAttempts = Array.from(this.reconnectionAttempts.values())
      .reduce((total, attempt) => total + attempt.attempts, 0);

    return {
      activeReconnections: this.reconnectionAttempts.size,
      activeTimeouts: this.playerTimeouts.size,
      backupCount: this.gameStateBackups.size,
      totalReconnectionAttempts: totalAttempts
    };
  }

  public async shutdown(): Promise<void> {
    console.log('Shutting down resilience manager...');
    
    // Clear all timeouts
    for (const timeout of this.playerTimeouts.values()) {
      clearTimeout(timeout.timeoutId);
    }

    // Clear all data structures
    this.reconnectionAttempts.clear();
    this.playerTimeouts.clear();
    this.gameStateBackups.clear();
    
    console.log('Resilience manager shutdown complete');
  }
}

export const resilienceManager = new ResilienceManager();