import { Difficulty } from '../types/question';

export interface ScoreCalculationInput {
  questionDifficulty: Difficulty;
  isCorrect: boolean;
  responseTime: number; // in milliseconds
  timeLimit: number; // in milliseconds
  questionPointValue?: number;
  playerStreak?: number;
  totalQuestionsAnswered?: number;
  correctAnswersInSession?: number;
}

export interface ScoreBreakdown {
  basePoints: number;
  speedBonus: number;
  accuracyBonus: number;
  streakBonus: number;
  difficultyMultiplier: number;
  totalPoints: number;
  breakdown: {
    base: string;
    speed: string;
    accuracy: string;
    streak: string;
    difficulty: string;
  };
}

export interface PlayerPerformanceMetrics {
  totalScore: number;
  accuracy: number; // percentage
  averageResponseTime: number; // in milliseconds
  currentStreak: number;
  longestStreak: number;
  questionsAnswered: number;
  correctAnswers: number;
  categoryPerformance: Map<string, {
    correct: number;
    total: number;
    averageTime: number;
  }>;
  difficultyPerformance: Map<Difficulty, {
    correct: number;
    total: number;
    averageTime: number;
  }>;
}

export class ScoringService {
  private readonly DIFFICULTY_MULTIPLIERS = {
    [Difficulty.EASY]: 1.0,
    [Difficulty.MEDIUM]: 1.5,
    [Difficulty.HARD]: 2.0
  };

  private readonly BASE_POINTS = {
    [Difficulty.EASY]: 10,
    [Difficulty.MEDIUM]: 20,
    [Difficulty.HARD]: 30
  };

  private readonly SPEED_BONUS_MULTIPLIER = 0.5; // Points per second saved
  private readonly ACCURACY_BONUS_THRESHOLD = 0.8; // 80% accuracy needed for bonus
  private readonly ACCURACY_BONUS_POINTS = 5;
  private readonly STREAK_BONUS_MULTIPLIER = 2; // Points per streak count
  private readonly MAX_SPEED_BONUS = 50; // Maximum speed bonus points
  private readonly CONSISTENCY_THRESHOLD = 5; // Minimum questions for consistency bonus

  /**
   * Calculate score for a single question answer
   */
  public calculateQuestionScore(input: ScoreCalculationInput): ScoreBreakdown {
    if (!input.isCorrect) {
      return {
        basePoints: 0,
        speedBonus: 0,
        accuracyBonus: 0,
        streakBonus: 0,
        difficultyMultiplier: 1,
        totalPoints: 0,
        breakdown: {
          base: 'Incorrect answer: 0 points',
          speed: 'No speed bonus for incorrect answer',
          accuracy: 'No accuracy bonus for incorrect answer',
          streak: 'Streak broken',
          difficulty: 'No difficulty multiplier applied'
        }
      };
    }

    // Calculate base points
    const basePoints = input.questionPointValue || this.BASE_POINTS[input.questionDifficulty];
    
    // Calculate speed bonus
    const speedBonus = this.calculateSpeedBonus(input.responseTime, input.timeLimit);
    
    // Calculate accuracy bonus (if applicable)
    const accuracyBonus = this.calculateAccuracyBonus(
      input.correctAnswersInSession || 1,
      input.totalQuestionsAnswered || 1
    );
    
    // Calculate streak bonus
    const streakBonus = this.calculateStreakBonus(input.playerStreak || 0);
    
    // Apply difficulty multiplier
    const difficultyMultiplier = this.DIFFICULTY_MULTIPLIERS[input.questionDifficulty];
    
    // Calculate total points
    const subtotal = basePoints + speedBonus + accuracyBonus + streakBonus;
    const totalPoints = Math.round(subtotal * difficultyMultiplier);

    return {
      basePoints,
      speedBonus,
      accuracyBonus,
      streakBonus,
      difficultyMultiplier,
      totalPoints,
      breakdown: {
        base: `Base points for ${input.questionDifficulty.toLowerCase()} question: ${basePoints}`,
        speed: speedBonus > 0 
          ? `Speed bonus (${(input.timeLimit - input.responseTime) / 1000}s saved): +${speedBonus}`
          : 'No speed bonus',
        accuracy: accuracyBonus > 0 
          ? `Accuracy bonus (${Math.round((input.correctAnswersInSession || 0) / (input.totalQuestionsAnswered || 1) * 100)}% accuracy): +${accuracyBonus}`
          : 'No accuracy bonus',
        streak: streakBonus > 0 
          ? `Streak bonus (${input.playerStreak} correct in a row): +${streakBonus}`
          : 'No streak bonus',
        difficulty: `Difficulty multiplier (${input.questionDifficulty.toLowerCase()}): ×${difficultyMultiplier}`
      }
    };
  }

  /**
   * Calculate speed bonus based on response time
   */
  private calculateSpeedBonus(responseTime: number, timeLimit: number): number {
    if (responseTime >= timeLimit) {
      return 0; // No bonus if answered at or after time limit
    }

    const timeSaved = timeLimit - responseTime;
    const timeSavedSeconds = timeSaved / 1000;
    
    // Calculate bonus: more points for faster answers
    const bonus = Math.floor(timeSavedSeconds * this.SPEED_BONUS_MULTIPLIER);
    
    // Cap the speed bonus
    return Math.min(bonus, this.MAX_SPEED_BONUS);
  }

  /**
   * Calculate accuracy bonus for maintaining high accuracy
   */
  private calculateAccuracyBonus(correctAnswers: number, totalAnswers: number): number {
    if (totalAnswers < this.CONSISTENCY_THRESHOLD) {
      return 0; // Need minimum questions for accuracy bonus
    }

    const accuracy = correctAnswers / totalAnswers;
    
    if (accuracy >= this.ACCURACY_BONUS_THRESHOLD) {
      // Bonus increases with higher accuracy
      const bonusMultiplier = Math.floor((accuracy - this.ACCURACY_BONUS_THRESHOLD) * 10) + 1;
      return this.ACCURACY_BONUS_POINTS * bonusMultiplier;
    }

    return 0;
  }

  /**
   * Calculate streak bonus for consecutive correct answers
   */
  private calculateStreakBonus(streak: number): number {
    if (streak < 2) {
      return 0; // Need at least 2 in a row for streak bonus
    }

    // Exponential growth for longer streaks, but capped
    const bonus = Math.floor(Math.pow(streak - 1, 1.2) * this.STREAK_BONUS_MULTIPLIER);
    return Math.min(bonus, 100); // Cap streak bonus at 100 points
  }

  /**
   * Update player performance metrics
   */
  public updatePlayerMetrics(
    currentMetrics: PlayerPerformanceMetrics,
    questionCategory: string,
    questionDifficulty: Difficulty,
    isCorrect: boolean,
    responseTime: number,
    pointsEarned: number
  ): PlayerPerformanceMetrics {
    const updatedMetrics = { ...currentMetrics };

    // Update basic stats
    updatedMetrics.totalScore += pointsEarned;
    updatedMetrics.questionsAnswered += 1;
    
    if (isCorrect) {
      updatedMetrics.correctAnswers += 1;
      updatedMetrics.currentStreak += 1;
      updatedMetrics.longestStreak = Math.max(
        updatedMetrics.longestStreak,
        updatedMetrics.currentStreak
      );
    } else {
      updatedMetrics.currentStreak = 0;
    }

    // Update accuracy
    updatedMetrics.accuracy = (updatedMetrics.correctAnswers / updatedMetrics.questionsAnswered) * 100;

    // Update average response time
    const totalResponseTime = updatedMetrics.averageResponseTime * (updatedMetrics.questionsAnswered - 1) + responseTime;
    updatedMetrics.averageResponseTime = totalResponseTime / updatedMetrics.questionsAnswered;

    // Update category performance
    if (!updatedMetrics.categoryPerformance.has(questionCategory)) {
      updatedMetrics.categoryPerformance.set(questionCategory, {
        correct: 0,
        total: 0,
        averageTime: 0
      });
    }
    
    const categoryStats = updatedMetrics.categoryPerformance.get(questionCategory)!;
    const newCategoryTotal = categoryStats.total + 1;
    const newCategoryAvgTime = (categoryStats.averageTime * categoryStats.total + responseTime) / newCategoryTotal;
    
    updatedMetrics.categoryPerformance.set(questionCategory, {
      correct: categoryStats.correct + (isCorrect ? 1 : 0),
      total: newCategoryTotal,
      averageTime: newCategoryAvgTime
    });

    // Update difficulty performance
    if (!updatedMetrics.difficultyPerformance.has(questionDifficulty)) {
      updatedMetrics.difficultyPerformance.set(questionDifficulty, {
        correct: 0,
        total: 0,
        averageTime: 0
      });
    }
    
    const difficultyStats = updatedMetrics.difficultyPerformance.get(questionDifficulty)!;
    const newDifficultyTotal = difficultyStats.total + 1;
    const newDifficultyAvgTime = (difficultyStats.averageTime * difficultyStats.total + responseTime) / newDifficultyTotal;
    
    updatedMetrics.difficultyPerformance.set(questionDifficulty, {
      correct: difficultyStats.correct + (isCorrect ? 1 : 0),
      total: newDifficultyTotal,
      averageTime: newDifficultyAvgTime
    });

    return updatedMetrics;
  }

  /**
   * Calculate final game score with end-game bonuses
   */
  public calculateFinalGameScore(
    baseScore: number,
    metrics: PlayerPerformanceMetrics,
    gameMode: string
  ): {
    finalScore: number;
    bonuses: {
      perfectGame: number;
      speedDemon: number;
      consistency: number;
      difficulty: number;
    };
  } {
    const bonuses = {
      perfectGame: 0,
      speedDemon: 0,
      consistency: 0,
      difficulty: 0
    };

    // Perfect game bonus (100% accuracy)
    if (metrics.accuracy === 100 && metrics.questionsAnswered >= 5) {
      bonuses.perfectGame = Math.floor(baseScore * 0.2); // 20% bonus
    }

    // Speed demon bonus (average response time under 5 seconds)
    if (metrics.averageResponseTime < 5000 && metrics.questionsAnswered >= 5) {
      bonuses.speedDemon = Math.floor(baseScore * 0.1); // 10% bonus
    }

    // Consistency bonus (accuracy above 90% with at least 10 questions)
    if (metrics.accuracy >= 90 && metrics.questionsAnswered >= 10) {
      bonuses.consistency = Math.floor(baseScore * 0.15); // 15% bonus
    }

    // Difficulty bonus (for answering hard questions correctly)
    const hardQuestionStats = metrics.difficultyPerformance.get(Difficulty.HARD);
    if (hardQuestionStats && hardQuestionStats.correct >= 3) {
      bonuses.difficulty = hardQuestionStats.correct * 10; // 10 points per hard question
    }

    const totalBonuses = Object.values(bonuses).reduce((sum, bonus) => sum + bonus, 0);
    const finalScore = baseScore + totalBonuses;

    return { finalScore, bonuses };
  }

  /**
   * Create initial player metrics
   */
  public createInitialMetrics(): PlayerPerformanceMetrics {
    return {
      totalScore: 0,
      accuracy: 0,
      averageResponseTime: 0,
      currentStreak: 0,
      longestStreak: 0,
      questionsAnswered: 0,
      correctAnswers: 0,
      categoryPerformance: new Map(),
      difficultyPerformance: new Map()
    };
  }

  /**
   * Get performance grade based on metrics
   */
  public getPerformanceGrade(metrics: PlayerPerformanceMetrics): {
    grade: 'A+' | 'A' | 'B+' | 'B' | 'C+' | 'C' | 'D' | 'F';
    description: string;
  } {
    const { accuracy, averageResponseTime, longestStreak } = metrics;

    // Calculate composite score
    const accuracyScore = accuracy;
    const speedScore = Math.max(0, 100 - (averageResponseTime / 1000) * 10); // Penalty for slow responses
    const streakScore = Math.min(100, longestStreak * 10); // Bonus for streaks

    const compositeScore = (accuracyScore * 0.5) + (speedScore * 0.3) + (streakScore * 0.2);

    if (compositeScore >= 95) return { grade: 'A+', description: 'Outstanding performance!' };
    if (compositeScore >= 90) return { grade: 'A', description: 'Excellent work!' };
    if (compositeScore >= 85) return { grade: 'B+', description: 'Very good performance!' };
    if (compositeScore >= 80) return { grade: 'B', description: 'Good job!' };
    if (compositeScore >= 75) return { grade: 'C+', description: 'Above average!' };
    if (compositeScore >= 70) return { grade: 'C', description: 'Average performance' };
    if (compositeScore >= 60) return { grade: 'D', description: 'Below average' };
    return { grade: 'F', description: 'Needs improvement' };
  }
}

export const scoringService = new ScoringService();