import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export interface PlayerStatistics {
  userId: string;
  username: string;
  gamesPlayed: number;
  totalScore: number;
  averageScore: number;
  accuracyRate: number;
  bestScore: number;
  worstScore: number;
  totalTimeSpent: number; // in milliseconds
  averageTimePerQuestion: number;
  longestStreak: number;
  categoryPerformance: CategoryPerformance[];
  difficultyPerformance: DifficultyPerformance[];
  recentGames: RecentGameSummary[];
  rank: number;
  percentile: number;
}

export interface CategoryPerformance {
  category: string;
  gamesPlayed: number;
  totalQuestions: number;
  correctAnswers: number;
  accuracy: number;
  averageScore: number;
  averageTimePerQuestion: number;
}

export interface DifficultyPerformance {
  difficulty: string;
  gamesPlayed: number;
  totalQuestions: number;
  correctAnswers: number;
  accuracy: number;
  averageScore: number;
  averageTimePerQuestion: number;
}

export interface RecentGameSummary {
  gameId: string;
  mode: string;
  score: number;
  accuracy: number;
  questionsAnswered: number;
  playedAt: Date;
  rank: number;
  totalPlayers: number;
}

export interface LeaderboardEntry {
  rank: number;
  userId: string;
  username: string;
  score: number;
  gamesPlayed: number;
  accuracyRate: number;
  averageScore: number;
}

export interface GlobalStatistics {
  totalPlayers: number;
  totalGames: number;
  totalQuestions: number;
  averageGameScore: number;
  averageAccuracy: number;
  mostPopularCategory: string;
  mostPopularDifficulty: string;
  averageGameDuration: number;
}

class StatisticsService {
  /**
   * Update player statistics after a game
   */
  public async updatePlayerStatistics(
    userId: string,
    gameSessionId: string,
    score: number,
    accuracy: number,
    questionsAnswered: number,
    totalTimeSpent: number
  ): Promise<void> {
    try {
      // Get current user stats
      const user = await prisma.user.findUnique({
        where: { id: userId }
      });

      if (!user) {
        throw new Error('User not found');
      }

      // Calculate new averages
      const newGamesPlayed = user.gamesPlayed + 1;
      const newTotalScore = user.totalScore + score;
      const newAverageScore = newTotalScore / newGamesPlayed;
      
      // Calculate new accuracy (weighted average)
      const totalQuestionsAnswered = (user.gamesPlayed * 10) + questionsAnswered; // Assuming 10 questions per game average
      const totalCorrectAnswers = (user.accuracyRate / 100) * (user.gamesPlayed * 10) + (accuracy / 100) * questionsAnswered;
      const newAccuracyRate = (totalCorrectAnswers / totalQuestionsAnswered) * 100;

      // Update user statistics
      await prisma.user.update({
        where: { id: userId },
        data: {
          gamesPlayed: newGamesPlayed,
          totalScore: newTotalScore,
          averageScore: newAverageScore,
          accuracyRate: newAccuracyRate
        }
      });

      console.log(`Updated statistics for user ${userId}: Games: ${newGamesPlayed}, Avg Score: ${newAverageScore.toFixed(1)}, Accuracy: ${newAccuracyRate.toFixed(1)}%`);
    } catch (error) {
      console.error('Error updating player statistics:', error);
      throw error;
    }
  }

  /**
   * Get comprehensive player statistics
   */
  public async getPlayerStatistics(userId: string): Promise<PlayerStatistics> {
    try {
      const user = await prisma.user.findUnique({
        where: { id: userId },
        include: {
          gameParticipations: {
            include: {
              gameSession: true,
              answers: {
                include: {
                  gameQuestion: {
                    include: {
                      question: true
                    }
                  }
                }
              }
            },
            orderBy: {
              joinedAt: 'desc'
            },
            take: 10 // Last 10 games
          }
        }
      });

      if (!user) {
        throw new Error('User not found');
      }

      // Calculate detailed statistics
      const categoryStats = await this.calculateCategoryPerformance(userId);
      const difficultyStats = await this.calculateDifficultyPerformance(userId);
      const recentGames = await this.getRecentGameSummaries(userId);
      const { rank, percentile } = await this.calculatePlayerRank(userId);

      // Calculate additional metrics
      const scores = user.gameParticipations.map(p => p.score);
      const bestScore = scores.length > 0 ? Math.max(...scores) : 0;
      const worstScore = scores.length > 0 ? Math.min(...scores) : 0;

      // Calculate total time spent and average time per question
      let totalTimeSpent = 0;
      let totalQuestions = 0;
      let longestStreak = 0;

      for (const participation of user.gameParticipations) {
        for (const answer of participation.answers) {
          totalTimeSpent += answer.timeToAnswer;
          totalQuestions++;
        }
      }

      const averageTimePerQuestion = totalQuestions > 0 ? totalTimeSpent / totalQuestions : 0;

      return {
        userId: user.id,
        username: user.username,
        gamesPlayed: user.gamesPlayed,
        totalScore: user.totalScore,
        averageScore: user.averageScore,
        accuracyRate: user.accuracyRate,
        bestScore,
        worstScore,
        totalTimeSpent,
        averageTimePerQuestion,
        longestStreak, // TODO: Calculate from game data
        categoryPerformance: categoryStats,
        difficultyPerformance: difficultyStats,
        recentGames,
        rank,
        percentile
      };
    } catch (error) {
      console.error('Error getting player statistics:', error);
      throw error;
    }
  }

  /**
   * Get global leaderboard
   */
  public async getGlobalLeaderboard(
    limit: number = 50,
    sortBy: 'totalScore' | 'averageScore' | 'accuracyRate' | 'gamesPlayed' = 'totalScore'
  ): Promise<LeaderboardEntry[]> {
    try {
      const users = await prisma.user.findMany({
        where: {
          gamesPlayed: {
            gt: 0 // Only include users who have played at least one game
          }
        },
        orderBy: {
          [sortBy]: 'desc'
        },
        take: limit,
        select: {
          id: true,
          username: true,
          totalScore: true,
          gamesPlayed: true,
          accuracyRate: true,
          averageScore: true
        }
      });

      return users.map((user, index) => ({
        rank: index + 1,
        userId: user.id,
        username: user.username,
        score: user.totalScore,
        gamesPlayed: user.gamesPlayed,
        accuracyRate: user.accuracyRate,
        averageScore: user.averageScore
      }));
    } catch (error) {
      console.error('Error getting global leaderboard:', error);
      throw error;
    }
  }

  /**
   * Get category-specific leaderboard
   */
  public async getCategoryLeaderboard(category: string, limit: number = 20): Promise<LeaderboardEntry[]> {
    try {
      // This is a simplified version - in a real implementation, you'd want to track category-specific scores
      const categoryStats = await prisma.$queryRaw<any[]>`
        SELECT 
          u.id as "userId",
          u.username,
          COUNT(pa.id) as "totalAnswers",
          SUM(CASE WHEN pa."isCorrect" THEN 1 ELSE 0 END) as "correctAnswers",
          SUM(pa."pointsEarned") as "totalPoints",
          AVG(pa."pointsEarned") as "averagePoints"
        FROM users u
        JOIN game_participants gp ON u.id = gp."userId"
        JOIN player_answers pa ON gp.id = pa."participantId"
        JOIN game_questions gq ON pa."gameQuestionId" = gq.id
        JOIN questions q ON gq."questionId" = q.id
        WHERE q.category = ${category}
        GROUP BY u.id, u.username
        HAVING COUNT(pa.id) >= 5
        ORDER BY "totalPoints" DESC
        LIMIT ${limit}
      `;

      return categoryStats.map((stat, index) => ({
        rank: index + 1,
        userId: stat.userId,
        username: stat.username,
        score: parseInt(stat.totalPoints),
        gamesPlayed: 0, // Would need additional query
        accuracyRate: (parseInt(stat.correctAnswers) / parseInt(stat.totalAnswers)) * 100,
        averageScore: parseFloat(stat.averagePoints)
      }));
    } catch (error) {
      console.error('Error getting category leaderboard:', error);
      throw error;
    }
  }

  /**
   * Get global statistics
   */
  public async getGlobalStatistics(): Promise<GlobalStatistics> {
    try {
      const [
        totalPlayers,
        totalGames,
        totalQuestions,
        avgStats,
        categoryStats,
        difficultyStats
      ] = await Promise.all([
        prisma.user.count({ where: { gamesPlayed: { gt: 0 } } }),
        prisma.gameSession.count({ where: { status: 'COMPLETED' } }),
        prisma.question.count(),
        prisma.user.aggregate({
          where: { gamesPlayed: { gt: 0 } },
          _avg: {
            averageScore: true,
            accuracyRate: true
          }
        }),
        this.getMostPopularCategory(),
        this.getMostPopularDifficulty()
      ]);

      return {
        totalPlayers,
        totalGames,
        totalQuestions,
        averageGameScore: avgStats._avg.averageScore || 0,
        averageAccuracy: avgStats._avg.accuracyRate || 0,
        mostPopularCategory: categoryStats,
        mostPopularDifficulty: difficultyStats,
        averageGameDuration: 300000 // 5 minutes default - would calculate from actual data
      };
    } catch (error) {
      console.error('Error getting global statistics:', error);
      throw error;
    }
  }

  private async calculateCategoryPerformance(userId: string): Promise<CategoryPerformance[]> {
    try {
      const categoryStats = await prisma.$queryRaw<any[]>`
        SELECT 
          q.category,
          COUNT(DISTINCT gp."gameSessionId") as "gamesPlayed",
          COUNT(pa.id) as "totalQuestions",
          SUM(CASE WHEN pa."isCorrect" THEN 1 ELSE 0 END) as "correctAnswers",
          AVG(pa."pointsEarned") as "averageScore",
          AVG(pa."timeToAnswer") as "averageTime"
        FROM game_participants gp
        JOIN player_answers pa ON gp.id = pa."participantId"
        JOIN game_questions gq ON pa."gameQuestionId" = gq.id
        JOIN questions q ON gq."questionId" = q.id
        WHERE gp."userId" = ${userId}
        GROUP BY q.category
        ORDER BY "gamesPlayed" DESC
      `;

      return categoryStats.map(stat => ({
        category: stat.category,
        gamesPlayed: parseInt(stat.gamesPlayed),
        totalQuestions: parseInt(stat.totalQuestions),
        correctAnswers: parseInt(stat.correctAnswers),
        accuracy: (parseInt(stat.correctAnswers) / parseInt(stat.totalQuestions)) * 100,
        averageScore: parseFloat(stat.averageScore),
        averageTimePerQuestion: parseFloat(stat.averageTime)
      }));
    } catch (error) {
      console.error('Error calculating category performance:', error);
      return [];
    }
  }

  private async calculateDifficultyPerformance(userId: string): Promise<DifficultyPerformance[]> {
    try {
      const difficultyStats = await prisma.$queryRaw<any[]>`
        SELECT 
          q.difficulty,
          COUNT(DISTINCT gp."gameSessionId") as "gamesPlayed",
          COUNT(pa.id) as "totalQuestions",
          SUM(CASE WHEN pa."isCorrect" THEN 1 ELSE 0 END) as "correctAnswers",
          AVG(pa."pointsEarned") as "averageScore",
          AVG(pa."timeToAnswer") as "averageTime"
        FROM game_participants gp
        JOIN player_answers pa ON gp.id = pa."participantId"
        JOIN game_questions gq ON pa."gameQuestionId" = gq.id
        JOIN questions q ON gq."questionId" = q.id
        WHERE gp."userId" = ${userId}
        GROUP BY q.difficulty
        ORDER BY "gamesPlayed" DESC
      `;

      return difficultyStats.map(stat => ({
        difficulty: stat.difficulty,
        gamesPlayed: parseInt(stat.gamesPlayed),
        totalQuestions: parseInt(stat.totalQuestions),
        correctAnswers: parseInt(stat.correctAnswers),
        accuracy: (parseInt(stat.correctAnswers) / parseInt(stat.totalQuestions)) * 100,
        averageScore: parseFloat(stat.averageScore),
        averageTimePerQuestion: parseFloat(stat.averageTime)
      }));
    } catch (error) {
      console.error('Error calculating difficulty performance:', error);
      return [];
    }
  }

  private async getRecentGameSummaries(userId: string): Promise<RecentGameSummary[]> {
    try {
      const recentGames = await prisma.gameParticipant.findMany({
        where: { userId },
        include: {
          gameSession: true
        },
        orderBy: {
          joinedAt: 'desc'
        },
        take: 10
      });

      const summaries: RecentGameSummary[] = [];

      for (const game of recentGames) {
        // Get total participants for rank calculation
        const totalParticipants = await prisma.gameParticipant.count({
          where: { gameSessionId: game.gameSessionId }
        });

        // Get rank (simplified - would need more complex query for actual rank)
        const betterScores = await prisma.gameParticipant.count({
          where: {
            gameSessionId: game.gameSessionId,
            score: { gt: game.score }
          }
        });

        summaries.push({
          gameId: game.gameSessionId,
          mode: game.gameSession.mode,
          score: game.score,
          accuracy: game.accuracy,
          questionsAnswered: game.gameSession.questionCount,
          playedAt: game.joinedAt,
          rank: betterScores + 1,
          totalPlayers: totalParticipants
        });
      }

      return summaries;
    } catch (error) {
      console.error('Error getting recent game summaries:', error);
      return [];
    }
  }

  private async calculatePlayerRank(userId: string): Promise<{ rank: number; percentile: number }> {
    try {
      const user = await prisma.user.findUnique({
        where: { id: userId },
        select: { totalScore: true }
      });

      if (!user) {
        return { rank: 0, percentile: 0 };
      }

      const betterPlayers = await prisma.user.count({
        where: {
          totalScore: { gt: user.totalScore },
          gamesPlayed: { gt: 0 }
        }
      });

      const totalPlayers = await prisma.user.count({
        where: { gamesPlayed: { gt: 0 } }
      });

      const rank = betterPlayers + 1;
      const percentile = totalPlayers > 0 ? ((totalPlayers - rank + 1) / totalPlayers) * 100 : 0;

      return { rank, percentile };
    } catch (error) {
      console.error('Error calculating player rank:', error);
      return { rank: 0, percentile: 0 };
    }
  }

  private async getMostPopularCategory(): Promise<string> {
    try {
      const result = await prisma.$queryRaw<any[]>`
        SELECT q.category, COUNT(*) as count
        FROM player_answers pa
        JOIN game_questions gq ON pa."gameQuestionId" = gq.id
        JOIN questions q ON gq."questionId" = q.id
        GROUP BY q.category
        ORDER BY count DESC
        LIMIT 1
      `;

      return result.length > 0 ? result[0].category : 'Science';
    } catch (error) {
      console.error('Error getting most popular category:', error);
      return 'Science';
    }
  }

  private async getMostPopularDifficulty(): Promise<string> {
    try {
      const result = await prisma.$queryRaw<any[]>`
        SELECT q.difficulty, COUNT(*) as count
        FROM player_answers pa
        JOIN game_questions gq ON pa."gameQuestionId" = gq.id
        JOIN questions q ON gq."questionId" = q.id
        GROUP BY q.difficulty
        ORDER BY count DESC
        LIMIT 1
      `;

      return result.length > 0 ? result[0].difficulty : 'MEDIUM';
    } catch (error) {
      console.error('Error getting most popular difficulty:', error);
      return 'MEDIUM';
    }
  }
}

export const statisticsService = new StatisticsService();