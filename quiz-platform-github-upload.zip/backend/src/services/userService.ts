import { PrismaClient } from '@prisma/client';
import { UpdateProfileRequest, UserProfile } from '../types/user';

const prisma = new PrismaClient();

export class UserService {
  async getUserProfile(userId: string): Promise<UserProfile> {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        username: true,
        email: true,
        createdAt: true,
        gamesPlayed: true,
        totalScore: true,
        averageScore: true,
        accuracyRate: true
      }
    });

    if (!user) {
      throw new Error('User not found');
    }

    return {
      id: user.id,
      username: user.username,
      email: user.email,
      createdAt: user.createdAt,
      statistics: {
        gamesPlayed: user.gamesPlayed,
        totalScore: user.totalScore,
        averageScore: user.averageScore,
        accuracyRate: user.accuracyRate
      }
    };
  }

  async updateUserProfile(userId: string, data: UpdateProfileRequest): Promise<UserProfile> {
    // Check if username is already taken by another user
    if (data.username) {
      const existingUser = await prisma.user.findFirst({
        where: {
          username: data.username,
          NOT: { id: userId }
        }
      });

      if (existingUser) {
        throw new Error('Username already taken');
      }
    }

    // Check if email is already taken by another user
    if (data.email) {
      const existingUser = await prisma.user.findFirst({
        where: {
          email: data.email,
          NOT: { id: userId }
        }
      });

      if (existingUser) {
        throw new Error('Email already registered');
      }
    }

    const updatedUser = await prisma.user.update({
      where: { id: userId },
      data: {
        ...(data.username && { username: data.username }),
        ...(data.email && { email: data.email }),
        updatedAt: new Date()
      },
      select: {
        id: true,
        username: true,
        email: true,
        createdAt: true,
        gamesPlayed: true,
        totalScore: true,
        averageScore: true,
        accuracyRate: true
      }
    });

    return {
      id: updatedUser.id,
      username: updatedUser.username,
      email: updatedUser.email,
      createdAt: updatedUser.createdAt,
      statistics: {
        gamesPlayed: updatedUser.gamesPlayed,
        totalScore: updatedUser.totalScore,
        averageScore: updatedUser.averageScore,
        accuracyRate: updatedUser.accuracyRate
      }
    };
  }

  async getUserStats(userId: string) {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        gamesPlayed: true,
        totalScore: true,
        averageScore: true,
        accuracyRate: true
      }
    });

    if (!user) {
      throw new Error('User not found');
    }

    // TODO: Implement category performance tracking when game system is built
    const categoryPerformance: Record<string, number> = {};

    return {
      gamesPlayed: user.gamesPlayed,
      totalScore: user.totalScore,
      averageScore: user.averageScore,
      accuracyRate: user.accuracyRate,
      categoryPerformance
    };
  }

  async getAllUsers(limit: number = 50, offset: number = 0) {
    const users = await prisma.user.findMany({
      skip: offset,
      take: limit,
      select: {
        id: true,
        username: true,
        createdAt: true,
        gamesPlayed: true,
        totalScore: true,
        averageScore: true,
        accuracyRate: true
      },
      orderBy: {
        totalScore: 'desc'
      }
    });

    return users;
  }

  async searchUsers(query: string, limit: number = 20) {
    const users = await prisma.user.findMany({
      where: {
        username: {
          contains: query,
          mode: 'insensitive'
        }
      },
      take: limit,
      select: {
        id: true,
        username: true,
        createdAt: true,
        gamesPlayed: true,
        totalScore: true
      },
      orderBy: {
        username: 'asc'
      }
    });

    return users;
  }
}