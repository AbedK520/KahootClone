export enum QuestionType {
  MULTIPLE_CHOICE = 'MULTIPLE_CHOICE',
  TRUE_FALSE = 'TRUE_FALSE',
  TEXT_INPUT = 'TEXT_INPUT'
}

export enum Difficulty {
  EASY = 'EASY',
  MEDIUM = 'MEDIUM',
  HARD = 'HARD'
}

export interface CreateQuestionRequest {
  text: string;
  type: QuestionType;
  category: string;
  difficulty: Difficulty;
  options?: string[];
  correctAnswer: string;
  explanation?: string;
}

export interface QuestionResponse {
  id: string;
  text: string;
  type: QuestionType;
  category: string;
  difficulty: Difficulty;
  options?: string[];
  explanation?: string;
  pointValue: number;
  createdAt: Date;
}

export interface QuestionForGame {
  id: string;
  text: string;
  type: QuestionType;
  category: string;
  difficulty: Difficulty;
  options?: string[];
  pointValue: number;
}

export interface QuestionFilters {
  categories?: string[];
  difficulties?: Difficulty[];
  type?: QuestionType;
  limit?: number;
  offset?: number;
}