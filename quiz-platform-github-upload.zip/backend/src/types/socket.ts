import { QuestionResponse } from './question';

import { PlayerPerformanceMetrics } from '../services/scoringService';

export interface Player {
  id: string;
  username: string;
  socketId: string;
  score: number;
  isConnected: boolean;
  joinedAt: Date;
  metrics: PlayerPerformanceMetrics;
  currentStreak: number;
}

export interface GameSession {
  id: string;
  mode: 'quick-match' | 'team-battle' | 'tournament' | 'practice';
  status: 'waiting' | 'in-progress' | 'completed';
  players: Map<string, Player>;
  maxPlayers: number;
  questions: any[];
  currentQuestionIndex: number;
  currentQuestionStartTime?: Date;
  scores: Map<string, number>;
  answers: Map<string, Map<string, { answer: string; timestamp: Date }>>;
  createdAt: Date;
  settings: {
    questionCount: number;
    timePerQuestion: number;
    categories: string[];
    difficulty: string[];
  };
}

export interface GameAnswer {
  playerId: string;
  answer: string;
  timestamp: Date;
}

// Socket Event Interfaces
export interface JoinGameData {
  gameId: string;
  playerId: string;
}

export interface CreateGameData {
  mode: 'quick-match' | 'team-battle' | 'tournament' | 'practice';
  maxPlayers: number;
  settings: {
    questionCount: number;
    timePerQuestion: number;
    categories: string[];
    difficulty: string[];
  };
}

export interface SubmitAnswerData {
  gameId: string;
  questionIndex: number;
  answer: string;
  timestamp: Date;
}

export interface QuestionPresentedData {
  question: Omit<QuestionResponse, 'correctAnswer'>;
  questionIndex: number;
  timeLimit: number;
  startTime: Date;
}

export interface RoundCompleteData {
  questionIndex: number;
  correctAnswer: string;
  scores: Record<string, number>;
  playerAnswers: Record<string, { 
    answer: string; 
    isCorrect: boolean; 
    points: number;
    scoreBreakdown: {
      basePoints: number;
      speedBonus: number;
      accuracyBonus: number;
      streakBonus: number;
      difficultyMultiplier: number;
      totalPoints: number;
    };
    responseTime: number;
    streak: number;
  }>;
}

export interface GameCompleteData {
  finalScores: Record<string, number>;
  rankings: Array<{ playerId: string; username: string; score: number; rank: number }>;
  statistics: {
    totalQuestions: number;
    gameMode: string;
    duration: number;
  };
}

export interface PlayerJoinedData {
  playerId: string;
  username: string;
  playerCount: number;
}

export interface PlayerDisconnectedData {
  playerId: string;
  username: string;
  playerCount: number;
}

export interface ScoreUpdateData {
  playerId: string;
  newScore: number;
  totalScore: number;
}

// Server to Client Events
export interface ServerToClientEvents {
  'game-created': (data: { gameId: string; game: Partial<GameSession> }) => void;
  'player-joined': (data: PlayerJoinedData) => void;
  'player-disconnected': (data: PlayerDisconnectedData) => void;
  'game-started': (data: { gameId: string; firstQuestion: QuestionPresentedData }) => void;
  'question-presented': (data: QuestionPresentedData) => void;
  'round-complete': (data: RoundCompleteData) => void;
  'game-complete': (data: GameCompleteData) => void;
  'score-update': (data: ScoreUpdateData) => void;
  'game-state-sync': (data: { gameId: string; state: Partial<GameSession> }) => void;
  'detailed-results': (data: { gameId: string; playerResults: any }) => void;
  'error': (data: { code: string; message: string }) => void;
  'reconnected': (data: { gameId: string; currentState: Partial<GameSession> }) => void;
}

// Client to Server Events
export interface ClientToServerEvents {
  'create-game': (data: CreateGameData, callback: (response: { success: boolean; gameId?: string; error?: string }) => void) => void;
  'join-game': (data: JoinGameData, callback: (response: { success: boolean; error?: string }) => void) => void;
  'start-game': (data: { gameId: string }, callback: (response: { success: boolean; error?: string }) => void) => void;
  'submit-answer': (data: SubmitAnswerData) => void;
  'leave-game': (data: { gameId: string }) => void;
  'reconnect-game': (data: { gameId: string }, callback: (response: { success: boolean; gameState?: Partial<GameSession>; error?: string }) => void) => void;
}

export interface InterServerEvents {
  ping: () => void;
}

export interface SocketData {
  user?: {
    userId: string;
    username: string;
    email: string;
  };
  gameId?: string;
}