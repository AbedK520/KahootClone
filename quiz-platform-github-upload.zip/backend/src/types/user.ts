export interface UpdateProfileRequest {
  username?: string;
  email?: string;
}

export interface UserProfile {
  id: string;
  username: string;
  email: string;
  createdAt: Date;
  statistics: {
    gamesPlayed: number;
    totalScore: number;
    averageScore: number;
    accuracyRate: number;
  };
}

export interface UserStats {
  gamesPlayed: number;
  totalScore: number;
  averageScore: number;
  accuracyRate: number;
  categoryPerformance: Record<string, number>;
}