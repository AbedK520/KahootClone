import React, { useEffect, useState } from 'react';
import { ScoreBreakdown } from './ScoreBreakdown';
import './AnswerFeedback.css';

interface AnswerFeedbackProps {
  isCorrect: boolean;
  userAnswer: string;
  correctAnswer: string;
  scoreBreakdown?: {
    basePoints: number;
    speedBonus: number;
    accuracyBonus: number;
    streakBonus: number;
    difficultyMultiplier: number;
    totalPoints: number;
  };
  explanations?: {
    base: string;
    speed: string;
    accuracy: string;
    streak: string;
    difficulty: string;
  };
  responseTime?: number;
  streak?: number;
  showAnimation?: boolean;
  onAnimationComplete?: () => void;
}

export const AnswerFeedback: React.FC<AnswerFeedbackProps> = ({
  isCorrect,
  userAnswer,
  correctAnswer,
  scoreBreakdown,
  explanations,
  responseTime,
  streak,
  showAnimation = true,
  onAnimationComplete
}) => {
  const [animationPhase, setAnimationPhase] = useState<'initial' | 'reveal' | 'complete'>('initial');

  useEffect(() => {
    if (showAnimation) {
      const timer1 = setTimeout(() => setAnimationPhase('reveal'), 500);
      const timer2 = setTimeout(() => {
        setAnimationPhase('complete');
        onAnimationComplete?.();
      }, 2000);

      return () => {
        clearTimeout(timer1);
        clearTimeout(timer2);
      };
    } else {
      setAnimationPhase('complete');
    }
  }, [showAnimation, onAnimationComplete]);

  const formatTime = (ms: number): string => {
    return `${(ms / 1000).toFixed(1)}s`;
  };

  const getStreakMessage = (streak: number): string => {
    if (streak === 0) return '';
    if (streak < 3) return `${streak} in a row! 🔥`;
    if (streak < 5) return `${streak} streak! You're on fire! 🔥🔥`;
    if (streak < 10) return `${streak} streak! Unstoppable! 🔥🔥🔥`;
    return `${streak} streak! LEGENDARY! 🔥🔥🔥🔥`;
  };

  return (
    <div className={`answer-feedback ${animationPhase !== 'initial' ? 'answer-feedback--revealed' : ''}`}>
      {/* Result Icon and Message */}
      <div className={`answer-feedback__result answer-feedback__result--${isCorrect ? 'correct' : 'incorrect'}`}>
        <div className="answer-feedback__icon">
          {isCorrect ? '✅' : '❌'}
        </div>
        <div className="answer-feedback__message">
          <h3 className="answer-feedback__title">
            {isCorrect ? 'Correct!' : 'Incorrect'}
          </h3>
          {responseTime && (
            <p className="answer-feedback__time">
              Answered in {formatTime(responseTime)}
            </p>
          )}
        </div>
      </div>

      {/* Answer Comparison */}
      <div className="answer-feedback__answers">
        <div className="answer-feedback__answer-item">
          <span className="answer-feedback__answer-label">Your answer:</span>
          <span className={`answer-feedback__answer-value answer-feedback__answer-value--${isCorrect ? 'correct' : 'incorrect'}`}>
            {userAnswer || 'No answer'}
          </span>
        </div>
        
        {!isCorrect && (
          <div className="answer-feedback__answer-item">
            <span className="answer-feedback__answer-label">Correct answer:</span>
            <span className="answer-feedback__answer-value answer-feedback__answer-value--correct">
              {correctAnswer}
            </span>
          </div>
        )}
      </div>

      {/* Streak Display */}
      {streak !== undefined && streak > 0 && (
        <div className="answer-feedback__streak">
          <div className="answer-feedback__streak-content">
            <span className="answer-feedback__streak-icon">🔥</span>
            <span className="answer-feedback__streak-text">
              {getStreakMessage(streak)}
            </span>
          </div>
        </div>
      )}

      {/* Score Breakdown */}
      {scoreBreakdown && animationPhase === 'complete' && (
        <div className="answer-feedback__score-section">
          <ScoreBreakdown
            breakdown={scoreBreakdown}
            explanations={explanations}
            showAnimations={true}
          />
        </div>
      )}

      {/* Points Animation */}
      {isCorrect && scoreBreakdown && animationPhase === 'reveal' && (
        <div className="answer-feedback__points-animation">
          <div className="answer-feedback__points-burst">
            +{scoreBreakdown.totalPoints}
          </div>
        </div>
      )}
    </div>
  );
};