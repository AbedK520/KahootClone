import React from 'react';
import { ScoreDisplay } from './ScoreDisplay';
import './GameResults.css';

interface PlayerMetrics {
  totalScore: number;
  accuracy: number;
  averageResponseTime: number;
  currentStreak: number;
  longestStreak: number;
  questionsAnswered: number;
  correctAnswers: number;
  categoryPerformance: Record<string, {
    correct: number;
    total: number;
    averageTime: number;
  }>;
  difficultyPerformance: Record<string, {
    correct: number;
    total: number;
    averageTime: number;
  }>;
}

interface GameResultsProps {
  playerResults: {
    baseScore: number;
    finalScore: number;
    bonuses: {
      perfectGame: number;
      speedDemon: number;
      consistency: number;
      difficulty: number;
    };
    metrics: PlayerMetrics;
    grade: {
      grade: 'A+' | 'A' | 'B+' | 'B' | 'C+' | 'C' | 'D' | 'F';
      description: string;
    };
    rank: number;
    totalPlayers: number;
  };
  gameStats: {
    totalQuestions: number;
    gameMode: string;
    duration: number;
  };
  onPlayAgain?: () => void;
  onBackToLobby?: () => void;
}

export const GameResults: React.FC<GameResultsProps> = ({
  playerResults,
  gameStats,
  onPlayAgain,
  onBackToLobby
}) => {
  const formatTime = (ms: number): string => {
    const minutes = Math.floor(ms / 60000);
    const seconds = Math.floor((ms % 60000) / 1000);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const formatResponseTime = (ms: number): string => {
    return `${(ms / 1000).toFixed(1)}s`;
  };

  const getGradeColor = (grade: string): string => {
    switch (grade) {
      case 'A+':
      case 'A': return '#22c55e';
      case 'B+':
      case 'B': return '#3b82f6';
      case 'C+':
      case 'C': return '#f59e0b';
      case 'D': return '#ef4444';
      case 'F': return '#dc2626';
      default: return '#6b7280';
    }
  };

  const getBonusItems = () => {
    const bonuses = [];
    if (playerResults.bonuses.perfectGame > 0) {
      bonuses.push({ label: 'Perfect Game', value: playerResults.bonuses.perfectGame, icon: '🎯' });
    }
    if (playerResults.bonuses.speedDemon > 0) {
      bonuses.push({ label: 'Speed Demon', value: playerResults.bonuses.speedDemon, icon: '⚡' });
    }
    if (playerResults.bonuses.consistency > 0) {
      bonuses.push({ label: 'Consistency', value: playerResults.bonuses.consistency, icon: '🎪' });
    }
    if (playerResults.bonuses.difficulty > 0) {
      bonuses.push({ label: 'Difficulty Master', value: playerResults.bonuses.difficulty, icon: '💪' });
    }
    return bonuses;
  };

  return (
    <div className="game-results">
      <div className="game-results__header">
        <div className="game-results__rank-display">
          <div className={`game-results__rank-circle game-results__rank-circle--${
            playerResults.rank === 1 ? 'first' : 
            playerResults.rank === 2 ? 'second' : 
            playerResults.rank === 3 ? 'third' : 'other'
          }`}>
            <span className="game-results__rank-number">{playerResults.rank}</span>
          </div>
          <div className="game-results__rank-text">
            <span className="game-results__rank-position">
              {playerResults.rank === 1 ? '1st Place!' : 
               playerResults.rank === 2 ? '2nd Place!' : 
               playerResults.rank === 3 ? '3rd Place!' : 
               `${playerResults.rank}th Place`}
            </span>
            <span className="game-results__rank-total">
              out of {playerResults.totalPlayers} players
            </span>
          </div>
        </div>

        <div className="game-results__score-display">
          <ScoreDisplay
            score={playerResults.finalScore}
            rank={playerResults.rank}
            totalPlayers={playerResults.totalPlayers}
            showRank={false}
            size="large"
          />
        </div>

        <div className="game-results__grade">
          <div 
            className="game-results__grade-circle"
            style={{ backgroundColor: getGradeColor(playerResults.grade.grade) }}
          >
            <span className="game-results__grade-letter">{playerResults.grade.grade}</span>
          </div>
          <span className="game-results__grade-description">
            {playerResults.grade.description}
          </span>
        </div>
      </div>

      <div className="game-results__content">
        {/* Score Breakdown */}
        <div className="game-results__section">
          <h3 className="game-results__section-title">Score Breakdown</h3>
          <div className="game-results__score-breakdown">
            <div className="game-results__score-item">
              <span className="game-results__score-label">Base Score</span>
              <span className="game-results__score-value">{playerResults.baseScore.toLocaleString()}</span>
            </div>
            
            {getBonusItems().map((bonus, index) => (
              <div key={index} className="game-results__score-item game-results__score-item--bonus">
                <span className="game-results__score-label">
                  <span className="game-results__bonus-icon">{bonus.icon}</span>
                  {bonus.label}
                </span>
                <span className="game-results__score-value">+{bonus.value.toLocaleString()}</span>
              </div>
            ))}
            
            <div className="game-results__score-total">
              <span className="game-results__score-label">Final Score</span>
              <span className="game-results__score-value">{playerResults.finalScore.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Performance Stats */}
        <div className="game-results__section">
          <h3 className="game-results__section-title">Performance Statistics</h3>
          <div className="game-results__stats-grid">
            <div className="game-results__stat">
              <span className="game-results__stat-value">{playerResults.metrics.accuracy.toFixed(1)}%</span>
              <span className="game-results__stat-label">Accuracy</span>
            </div>
            <div className="game-results__stat">
              <span className="game-results__stat-value">
                {formatResponseTime(playerResults.metrics.averageResponseTime)}
              </span>
              <span className="game-results__stat-label">Avg Response Time</span>
            </div>
            <div className="game-results__stat">
              <span className="game-results__stat-value">{playerResults.metrics.longestStreak}</span>
              <span className="game-results__stat-label">Longest Streak</span>
            </div>
            <div className="game-results__stat">
              <span className="game-results__stat-value">
                {playerResults.metrics.correctAnswers}/{playerResults.metrics.questionsAnswered}
              </span>
              <span className="game-results__stat-label">Correct Answers</span>
            </div>
          </div>
        </div>

        {/* Category Performance */}
        {Object.keys(playerResults.metrics.categoryPerformance).length > 0 && (
          <div className="game-results__section">
            <h3 className="game-results__section-title">Category Performance</h3>
            <div className="game-results__category-list">
              {Object.entries(playerResults.metrics.categoryPerformance).map(([category, stats]) => (
                <div key={category} className="game-results__category-item">
                  <div className="game-results__category-header">
                    <span className="game-results__category-name">{category}</span>
                    <span className="game-results__category-score">
                      {stats.correct}/{stats.total}
                    </span>
                  </div>
                  <div className="game-results__category-bar">
                    <div 
                      className="game-results__category-fill"
                      style={{ width: `${(stats.correct / stats.total) * 100}%` }}
                    ></div>
                  </div>
                  <div className="game-results__category-stats">
                    <span>{((stats.correct / stats.total) * 100).toFixed(0)}% accuracy</span>
                    <span>{formatResponseTime(stats.averageTime)} avg time</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Game Info */}
        <div className="game-results__section">
          <h3 className="game-results__section-title">Game Information</h3>
          <div className="game-results__game-info">
            <div className="game-results__info-item">
              <span className="game-results__info-label">Game Mode</span>
              <span className="game-results__info-value">{gameStats.gameMode}</span>
            </div>
            <div className="game-results__info-item">
              <span className="game-results__info-label">Duration</span>
              <span className="game-results__info-value">{formatTime(gameStats.duration)}</span>
            </div>
            <div className="game-results__info-item">
              <span className="game-results__info-label">Questions</span>
              <span className="game-results__info-value">{gameStats.totalQuestions}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="game-results__actions">
        {onPlayAgain && (
          <button 
            className="game-results__button game-results__button--primary"
            onClick={onPlayAgain}
          >
            Play Again
          </button>
        )}
        {onBackToLobby && (
          <button 
            className="game-results__button game-results__button--secondary"
            onClick={onBackToLobby}
          >
            Back to Lobby
          </button>
        )}
      </div>
    </div>
  );
};