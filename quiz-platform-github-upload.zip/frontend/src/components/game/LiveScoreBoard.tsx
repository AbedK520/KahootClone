import React, { useState, useEffect } from 'react';
import { ScoreDisplay } from './ScoreDisplay';
import './LiveScoreBoard.css';

interface Player {
  id: string;
  username: string;
  score: number;
  isConnected: boolean;
  streak?: number;
}

interface LiveScoreBoardProps {
  players: Player[];
  currentPlayerId?: string;
  showStreaks?: boolean;
  compact?: boolean;
}

export const LiveScoreBoard: React.FC<LiveScoreBoardProps> = ({
  players,
  currentPlayerId,
  showStreaks = false,
  compact = false
}) => {
  const [animatingPlayers, setAnimatingPlayers] = useState<Set<string>>(new Set());
  const [previousScores, setPreviousScores] = useState<Map<string, number>>(new Map());

  // Sort players by score (descending)
  const sortedPlayers = [...players].sort((a, b) => b.score - a.score);

  useEffect(() => {
    // Detect score changes and trigger animations
    const newAnimatingPlayers = new Set<string>();
    
    players.forEach(player => {
      const previousScore = previousScores.get(player.id) || 0;
      if (player.score > previousScore) {
        newAnimatingPlayers.add(player.id);
      }
    });

    if (newAnimatingPlayers.size > 0) {
      setAnimatingPlayers(newAnimatingPlayers);
      
      // Clear animations after delay
      setTimeout(() => {
        setAnimatingPlayers(new Set());
      }, 1000);
    }

    // Update previous scores
    const newPreviousScores = new Map();
    players.forEach(player => {
      newPreviousScores.set(player.id, player.score);
    });
    setPreviousScores(newPreviousScores);
  }, [players, previousScores]);

  // Helper function to get player rank (currently unused but may be needed later)
  // const getPlayerRank = (playerId: string): number => {
  //   return sortedPlayers.findIndex(p => p.id === playerId) + 1;
  // };

  const getStreakDisplay = (streak: number): string => {
    if (streak === 0) return '';
    if (streak < 3) return `🔥 ${streak}`;
    if (streak < 5) return `🔥🔥 ${streak}`;
    return `🔥🔥🔥 ${streak}`;
  };

  return (
    <div className={`live-scoreboard ${compact ? 'live-scoreboard--compact' : ''}`}>
      <div className="live-scoreboard__header">
        <h3 className="live-scoreboard__title">
          {compact ? 'Scores' : 'Live Scoreboard'}
        </h3>
        <div className="live-scoreboard__player-count">
          {players.filter(p => p.isConnected).length} players
        </div>
      </div>

      <div className="live-scoreboard__list">
        {sortedPlayers.map((player, index) => {
          const isCurrentPlayer = player.id === currentPlayerId;
          const isAnimating = animatingPlayers.has(player.id);
          const rank = index + 1;

          return (
            <div
              key={player.id}
              className={`
                live-scoreboard__player
                ${isCurrentPlayer ? 'live-scoreboard__player--current' : ''}
                ${!player.isConnected ? 'live-scoreboard__player--disconnected' : ''}
                ${isAnimating ? 'live-scoreboard__player--animating' : ''}
              `}
            >
              <div className="live-scoreboard__player-rank">
                <span className={`live-scoreboard__rank-number live-scoreboard__rank-number--${
                  rank === 1 ? 'first' : rank === 2 ? 'second' : rank === 3 ? 'third' : 'other'
                }`}>
                  {rank}
                </span>
              </div>

              <div className="live-scoreboard__player-info">
                <div className="live-scoreboard__player-name">
                  {player.username}
                  {isCurrentPlayer && <span className="live-scoreboard__you-badge">You</span>}
                  {!player.isConnected && <span className="live-scoreboard__disconnected-badge">Offline</span>}
                </div>
                
                {showStreaks && player.streak && player.streak > 0 && (
                  <div className="live-scoreboard__streak">
                    {getStreakDisplay(player.streak)}
                  </div>
                )}
              </div>

              <div className="live-scoreboard__player-score">
                <ScoreDisplay
                  score={player.score}
                  size="small"
                  animated={isAnimating}
                />
              </div>
            </div>
          );
        })}
      </div>

      {sortedPlayers.length === 0 && (
        <div className="live-scoreboard__empty">
          <p>No players yet</p>
        </div>
      )}
    </div>
  );
};