import React from 'react';
import './ScoreBreakdown.css';

interface ScoreBreakdownProps {
  breakdown: {
    basePoints: number;
    speedBonus: number;
    accuracyBonus: number;
    streakBonus: number;
    difficultyMultiplier: number;
    totalPoints: number;
  };
  explanations?: {
    base: string;
    speed: string;
    accuracy: string;
    streak: string;
    difficulty: string;
  };
  showAnimations?: boolean;
}

export const ScoreBreakdown: React.FC<ScoreBreakdownProps> = ({
  breakdown,
  explanations,
  showAnimations = false
}) => {
  const scoreItems = [
    {
      label: 'Base Points',
      value: breakdown.basePoints,
      explanation: explanations?.base,
      color: '#4f46e5',
      icon: '🎯'
    },
    {
      label: 'Speed Bonus',
      value: breakdown.speedBonus,
      explanation: explanations?.speed,
      color: '#059669',
      icon: '⚡'
    },
    {
      label: 'Accuracy Bonus',
      value: breakdown.accuracyBonus,
      explanation: explanations?.accuracy,
      color: '#dc2626',
      icon: '🎯'
    },
    {
      label: 'Streak Bonus',
      value: breakdown.streakBonus,
      explanation: explanations?.streak,
      color: '#7c2d12',
      icon: '🔥'
    }
  ];

  const hasMultiplier = breakdown.difficultyMultiplier !== 1;

  return (
    <div className="score-breakdown">
      <div className="score-breakdown__header">
        <h3 className="score-breakdown__title">Score Breakdown</h3>
      </div>

      <div className="score-breakdown__items">
        {scoreItems.map((item, index) => (
          <div
            key={item.label}
            className={`score-breakdown__item ${showAnimations ? 'score-breakdown__item--animated' : ''}`}
            style={{ animationDelay: showAnimations ? `${index * 0.1}s` : '0s' }}
          >
            <div className="score-breakdown__item-header">
              <span className="score-breakdown__icon">{item.icon}</span>
              <span className="score-breakdown__label">{item.label}</span>
              <span 
                className="score-breakdown__value"
                style={{ color: item.color }}
              >
                +{item.value}
              </span>
            </div>
            {item.explanation && (
              <div className="score-breakdown__explanation">
                {item.explanation}
              </div>
            )}
          </div>
        ))}

        {hasMultiplier && (
          <div className="score-breakdown__multiplier">
            <div className="score-breakdown__multiplier-header">
              <span className="score-breakdown__icon">⭐</span>
              <span className="score-breakdown__label">Difficulty Multiplier</span>
              <span className="score-breakdown__value score-breakdown__value--multiplier">
                ×{breakdown.difficultyMultiplier}
              </span>
            </div>
            {explanations?.difficulty && (
              <div className="score-breakdown__explanation">
                {explanations.difficulty}
              </div>
            )}
          </div>
        )}
      </div>

      <div className="score-breakdown__total">
        <div className="score-breakdown__total-line"></div>
        <div className="score-breakdown__total-content">
          <span className="score-breakdown__total-label">Total Points</span>
          <span className="score-breakdown__total-value">
            {breakdown.totalPoints}
          </span>
        </div>
      </div>
    </div>
  );
};