import React from 'react';
import './ScoreDisplay.css';

interface ScoreDisplayProps {
  score: number;
  rank?: number;
  totalPlayers?: number;
  showRank?: boolean;
  size?: 'small' | 'medium' | 'large';
  animated?: boolean;
}

export const ScoreDisplay: React.FC<ScoreDisplayProps> = ({
  score,
  rank,
  totalPlayers,
  showRank = false,
  size = 'medium',
  animated = false
}) => {
  const formatScore = (score: number): string => {
    return score.toLocaleString();
  };

  const getRankSuffix = (rank: number): string => {
    if (rank % 10 === 1 && rank % 100 !== 11) return 'st';
    if (rank % 10 === 2 && rank % 100 !== 12) return 'nd';
    if (rank % 10 === 3 && rank % 100 !== 13) return 'rd';
    return 'th';
  };

  const getRankColor = (rank: number, total: number): string => {
    const percentage = rank / total;
    if (percentage <= 0.1) return 'gold';
    if (percentage <= 0.25) return 'silver';
    if (percentage <= 0.5) return 'bronze';
    return 'default';
  };

  return (
    <div className={`score-display score-display--${size} ${animated ? 'score-display--animated' : ''}`}>
      <div className="score-display__score">
        <span className="score-display__number">{formatScore(score)}</span>
        <span className="score-display__label">Points</span>
      </div>
      
      {showRank && rank && totalPlayers && (
        <div className={`score-display__rank score-display__rank--${getRankColor(rank, totalPlayers)}`}>
          <span className="score-display__rank-number">
            {rank}{getRankSuffix(rank)}
          </span>
          <span className="score-display__rank-total">
            of {totalPlayers}
          </span>
        </div>
      )}
    </div>
  );
};