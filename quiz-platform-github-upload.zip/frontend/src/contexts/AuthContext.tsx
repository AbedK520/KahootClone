import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import authService, { User } from '../services/authService'

interface AuthContextType {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
  login: (email: string, password: string) => Promise<void>
  register: (username: string, email: string, password: string) => Promise<void>
  logout: () => Promise<void>
  refreshUser: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

interface AuthProviderProps {
  children: ReactNode
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    initializeAuth()
  }, [])

  const initializeAuth = async () => {
    try {
      if (authService.isAuthenticated()) {
        const userData = await authService.getCurrentUser()
        setUser(userData)
      }
    } catch (error) {
      // Token might be expired, clear it
      localStorage.removeItem('accessToken')
      localStorage.removeItem('refreshToken')
    } finally {
      setIsLoading(false)
    }
  }

  const login = async (email: string, password: string) => {
    const response = await authService.login({ email, password })
    authService.setTokens(response.accessToken, response.refreshToken)
    setUser({
      id: response.user.id,
      username: response.user.username,
      email: response.user.email,
      createdAt: response.user.createdAt,
      gamesPlayed: 0,
      totalScore: 0,
      averageScore: 0,
      accuracyRate: 0
    })
  }

  const register = async (username: string, email: string, password: string) => {
    const response = await authService.register({ username, email, password })
    authService.setTokens(response.accessToken, response.refreshToken)
    setUser({
      id: response.user.id,
      username: response.user.username,
      email: response.user.email,
      createdAt: response.user.createdAt,
      gamesPlayed: 0,
      totalScore: 0,
      averageScore: 0,
      accuracyRate: 0
    })
  }

  const logout = async () => {
    await authService.logout()
    setUser(null)
  }

  const refreshUser = async () => {
    if (authService.isAuthenticated()) {
      try {
        const userData = await authService.getCurrentUser()
        setUser(userData)
      } catch (error) {
        console.error('Failed to refresh user data:', error)
      }
    }
  }

  const value: AuthContextType = {
    user,
    isAuthenticated: !!user,
    isLoading,
    login,
    register,
    logout,
    refreshUser
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}