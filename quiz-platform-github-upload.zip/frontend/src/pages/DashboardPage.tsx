export default function DashboardPage() {
  return (
    <div className="max-w-6xl mx-auto">
      <h1 className="text-3xl font-bold mb-8">Dashboard</h1>
      
      <div className="grid lg:grid-cols-3 gap-8">
        {/* Quick Stats */}
        <div className="lg:col-span-2">
          <div className="card mb-8">
            <h2 className="text-xl font-semibold mb-4">Your Statistics</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-primary-600">0</div>
                <div className="text-sm text-gray-600">Games Played</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-success-600">0%</div>
                <div className="text-sm text-gray-600">Win Rate</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-primary-600">0</div>
                <div className="text-sm text-gray-600">Total Score</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-primary-600">0%</div>
                <div className="text-sm text-gray-600">Accuracy</div>
              </div>
            </div>
          </div>
          
          <div className="card">
            <h2 className="text-xl font-semibold mb-4">Recent Games</h2>
            <div className="text-center py-8 text-gray-500">
              No games played yet. Start your first game!
            </div>
          </div>
        </div>
        
        {/* Quick Actions */}
        <div>
          <div className="card">
            <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
            <div className="space-y-3">
              <button className="btn btn-primary w-full">
                Quick Match
              </button>
              <button className="btn btn-secondary w-full">
                Create Team
              </button>
              <button className="btn btn-secondary w-full">
                Join Tournament
              </button>
              <button className="btn btn-secondary w-full">
                Practice Mode
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}