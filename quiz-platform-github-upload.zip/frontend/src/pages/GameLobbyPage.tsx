import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

interface GameSettings {
  category: string;
  difficulty: string;
  questionCount: number;
  maxPlayers: number;
  timePerQuestion: number;
}

export default function GameLobbyPage() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [settings, setSettings] = useState<GameSettings>({
    category: 'all',
    difficulty: 'mixed',
    questionCount: 10,
    maxPlayers: 2,
    timePerQuestion: 30
  });

  const handleStartGame = (gameMode: string) => {
    console.log('Starting game:', gameMode, 'with settings:', settings);
    setIsLoading(true);
    setError('');
    setMessage(`Starting ${gameMode}...`);
    
    // Simulate game creation delay
    setTimeout(() => {
      setMessage(`${gameMode} started! Redirecting...`);
      
      // Navigate to game page after short delay
      setTimeout(() => {
        navigate('/game');
      }, 1000);
    }, 1000);
  };

  const handleComingSoon = (feature: string) => {
    setMessage(`${feature} is coming soon! 🚀`);
    setTimeout(() => {
      setMessage('');
    }, 2000);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-8">Game Lobby</h1>
      
      {/* Test Button */}
      <div className="mb-4">
        <button 
          className="bg-red-500 text-white px-4 py-2 rounded"
          onClick={() => alert('Test button works!')}
        >
          🔴 TEST BUTTON - Click Me!
        </button>
      </div>
      
      {/* Status Messages */}
      {message && (
        <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded mb-6">
          {message}
        </div>
      )}
      
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-6">
          {error}
        </div>
      )}
      
      <div className="grid lg:grid-cols-3 gap-8">
        {/* Game Modes */}
        <div className="lg:col-span-2">
          <div className="card mb-8">
            <h2 className="text-xl font-semibold mb-4">Select Game Mode</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <button 
                className="p-4 border-2 border-gray-200 rounded-lg hover:border-primary-500 hover:bg-primary-50 transition-colors disabled:opacity-50"
                onClick={() => handleStartGame('Quick Match')}
                disabled={isLoading}
              >
                <h3 className="font-semibold mb-2">Quick Match</h3>
                <p className="text-sm text-gray-600">Jump into a game instantly</p>
              </button>
              
              <button 
                className="p-4 border-2 border-gray-200 rounded-lg hover:border-primary-500 hover:bg-primary-50 transition-colors"
                onClick={() => handleComingSoon('Team Battle')}
                disabled={isLoading}
              >
                <h3 className="font-semibold mb-2">Team Battle</h3>
                <p className="text-sm text-gray-600">Compete with your team</p>
              </button>
              
              <button 
                className="p-4 border-2 border-gray-200 rounded-lg hover:border-primary-500 hover:bg-primary-50 transition-colors"
                onClick={() => handleComingSoon('Tournament')}
                disabled={isLoading}
              >
                <h3 className="font-semibold mb-2">Tournament</h3>
                <p className="text-sm text-gray-600">Elimination bracket competition</p>
              </button>
              
              <button 
                className="p-4 border-2 border-gray-200 rounded-lg hover:border-primary-500 hover:bg-primary-50 transition-colors disabled:opacity-50"
                onClick={() => handleStartGame('Practice Mode')}
                disabled={isLoading}
              >
                <h3 className="font-semibold mb-2">Practice</h3>
                <p className="text-sm text-gray-600">Improve your skills</p>
              </button>
            </div>
          </div>
          
          <div className="card">
            <h2 className="text-xl font-semibold mb-4">Active Games</h2>
            <div className="text-center py-8 text-gray-500">
              No active games. Create or join a game to get started!
            </div>
          </div>
        </div>
        
        {/* Game Settings */}
        <div>
          <div className="card">
            <h2 className="text-xl font-semibold mb-4">Game Settings</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Category
                </label>
                <select 
                  className="input"
                  value={settings.category}
                  onChange={(e) => setSettings({...settings, category: e.target.value})}
                >
                  <option value="all">All Categories</option>
                  <option value="Science">Science</option>
                  <option value="History">History</option>
                  <option value="Sports">Sports</option>
                  <option value="Entertainment">Entertainment</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Difficulty
                </label>
                <select 
                  className="input"
                  value={settings.difficulty}
                  onChange={(e) => setSettings({...settings, difficulty: e.target.value})}
                >
                  <option value="mixed">Mixed</option>
                  <option value="EASY">Easy</option>
                  <option value="MEDIUM">Medium</option>
                  <option value="HARD">Hard</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Questions
                </label>
                <select 
                  className="input"
                  value={settings.questionCount}
                  onChange={(e) => setSettings({...settings, questionCount: parseInt(e.target.value)})}
                >
                  <option value={5}>5 Questions</option>
                  <option value={10}>10 Questions</option>
                  <option value={15}>15 Questions</option>
                  <option value={20}>20 Questions</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Max Players
                </label>
                <select 
                  className="input"
                  value={settings.maxPlayers}
                  onChange={(e) => setSettings({...settings, maxPlayers: parseInt(e.target.value)})}
                >
                  <option value={2}>2 Players</option>
                  <option value={4}>4 Players</option>
                  <option value={6}>6 Players</option>
                  <option value={8}>8 Players</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Time per Question
                </label>
                <select 
                  className="input"
                  value={settings.timePerQuestion}
                  onChange={(e) => setSettings({...settings, timePerQuestion: parseInt(e.target.value)})}
                >
                  <option value={15}>15 seconds</option>
                  <option value={30}>30 seconds</option>
                  <option value={45}>45 seconds</option>
                  <option value={60}>60 seconds</option>
                </select>
              </div>
              
              <div className="pt-4 border-t">
                <p className="text-sm text-gray-600 mb-2">
                  {isLoading ? 'Starting game...' : 'Select a game mode above to start playing'}
                </p>
                
                <button 
                  className="btn btn-primary w-full"
                  onClick={() => handleStartGame('Quick Start')}
                  disabled={isLoading}
                >
                  {isLoading ? 'Starting...' : 'Quick Start'}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}