import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

interface Question {
  id: string;
  text: string;
  type: string;
  options?: string[];
  correctAnswer: string;
  category: string;
  difficulty: string;
}

interface GameState {
  currentQuestionIndex: number;
  score: number;
  timeLeft: number;
  isGameComplete: boolean;
  questions: Question[];
}

export default function GamePage() {
  const navigate = useNavigate();
  const [gameState, setGameState] = useState<GameState>({
    currentQuestionIndex: 0,
    score: 0,
    timeLeft: 30,
    isGameComplete: false,
    questions: []
  });
  const [selectedAnswer, setSelectedAnswer] = useState<string>('');
  const [showResult, setShowResult] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Sample questions for testing
  const sampleQuestions: Question[] = [
    {
      id: '1',
      text: 'What is the capital of France?',
      type: 'MULTIPLE_CHOICE',
      options: ['London', 'Berlin', 'Paris', 'Madrid'],
      correctAnswer: 'Paris',
      category: 'Geography',
      difficulty: 'EASY'
    },
    {
      id: '2',
      text: 'What is 2 + 2?',
      type: 'MULTIPLE_CHOICE',
      options: ['3', '4', '5', '6'],
      correctAnswer: '4',
      category: 'Math',
      difficulty: 'EASY'
    },
    {
      id: '3',
      text: 'Is the Earth round?',
      type: 'TRUE_FALSE',
      options: ['True', 'False'],
      correctAnswer: 'True',
      category: 'Science',
      difficulty: 'EASY'
    },
    {
      id: '4',
      text: 'What year did World War II end?',
      type: 'MULTIPLE_CHOICE',
      options: ['1944', '1945', '1946', '1947'],
      correctAnswer: '1945',
      category: 'History',
      difficulty: 'MEDIUM'
    },
    {
      id: '5',
      text: 'Which planet is closest to the Sun?',
      type: 'MULTIPLE_CHOICE',
      options: ['Venus', 'Earth', 'Mercury', 'Mars'],
      correctAnswer: 'Mercury',
      category: 'Science',
      difficulty: 'MEDIUM'
    }
  ];

  useEffect(() => {
    // Initialize game with sample questions
    setGameState(prev => ({
      ...prev,
      questions: sampleQuestions
    }));
    setIsLoading(false);
  }, []);

  useEffect(() => {
    // Timer countdown
    if (gameState.timeLeft > 0 && !showResult && !gameState.isGameComplete) {
      const timer = setTimeout(() => {
        setGameState(prev => ({
          ...prev,
          timeLeft: prev.timeLeft - 1
        }));
      }, 1000);
      return () => clearTimeout(timer);
    } else if (gameState.timeLeft === 0 && !showResult) {
      // Time's up, auto-submit
      handleSubmitAnswer();
    }
  }, [gameState.timeLeft, showResult, gameState.isGameComplete]);

  const currentQuestion = gameState.questions[gameState.currentQuestionIndex];

  const handleAnswerSelect = (answer: string) => {
    setSelectedAnswer(answer);
  };

  const handleSubmitAnswer = () => {
    if (!currentQuestion) return;

    const isCorrect = selectedAnswer === currentQuestion.correctAnswer;
    const points = isCorrect ? (currentQuestion.difficulty === 'EASY' ? 10 : currentQuestion.difficulty === 'MEDIUM' ? 20 : 30) : 0;
    
    setGameState(prev => ({
      ...prev,
      score: prev.score + points
    }));

    setShowResult(true);

    // Show result for 2 seconds, then move to next question
    setTimeout(() => {
      setShowResult(false);
      setSelectedAnswer('');
      
      if (gameState.currentQuestionIndex >= gameState.questions.length - 1) {
        // Game complete
        setGameState(prev => ({
          ...prev,
          isGameComplete: true
        }));
      } else {
        // Next question
        setGameState(prev => ({
          ...prev,
          currentQuestionIndex: prev.currentQuestionIndex + 1,
          timeLeft: 30
        }));
      }
    }, 2000);
  };

  const handlePlayAgain = () => {
    setGameState({
      currentQuestionIndex: 0,
      score: 0,
      timeLeft: 30,
      isGameComplete: false,
      questions: sampleQuestions
    });
    setSelectedAnswer('');
    setShowResult(false);
  };

  const handleBackToLobby = () => {
    navigate('/lobby');
  };

  if (isLoading) {
    return (
      <div className="max-w-2xl mx-auto text-center py-20">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500 mx-auto mb-4"></div>
        <p>Loading game...</p>
      </div>
    );
  }

  if (gameState.isGameComplete) {
    return (
      <div className="max-w-2xl mx-auto text-center py-20">
        <div className="card">
          <h1 className="text-3xl font-bold mb-4">🎉 Game Complete!</h1>
          <div className="text-6xl font-bold text-primary-500 mb-4">
            {gameState.score}
          </div>
          <p className="text-xl mb-2">Final Score</p>
          <p className="text-gray-600 mb-8">
            You answered {gameState.questions.length} questions
          </p>
          
          <div className="flex gap-4 justify-center">
            <button 
              className="btn btn-primary"
              onClick={handlePlayAgain}
            >
              Play Again
            </button>
            <button 
              className="btn btn-secondary"
              onClick={handleBackToLobby}
            >
              Back to Lobby
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!currentQuestion) {
    return (
      <div className="max-w-2xl mx-auto text-center py-20">
        <p>No questions available</p>
        <button className="btn btn-primary mt-4" onClick={handleBackToLobby}>
          Back to Lobby
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto py-8">
      {/* Game Header */}
      <div className="card mb-6">
        <div className="flex justify-between items-center">
          <div>
            <span className="text-sm text-gray-600">
              Question {gameState.currentQuestionIndex + 1} of {gameState.questions.length}
            </span>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-lg font-bold">
              Score: {gameState.score}
            </div>
            <div className={`text-lg font-bold ${gameState.timeLeft <= 10 ? 'text-red-500' : 'text-green-500'}`}>
              ⏰ {gameState.timeLeft}s
            </div>
          </div>
        </div>
        
        {/* Progress Bar */}
        <div className="w-full bg-gray-200 rounded-full h-2 mt-4">
          <div 
            className="bg-primary-500 h-2 rounded-full transition-all duration-300"
            style={{ width: `${((gameState.currentQuestionIndex + 1) / gameState.questions.length) * 100}%` }}
          ></div>
        </div>
      </div>

      {/* Question */}
      <div className="card mb-6">
        <div className="mb-4">
          <span className="inline-block bg-primary-100 text-primary-800 text-xs px-2 py-1 rounded-full mb-2">
            {currentQuestion.category} • {currentQuestion.difficulty}
          </span>
        </div>
        
        <h2 className="text-xl font-semibold mb-6">
          {currentQuestion.text}
        </h2>

        {/* Answer Options */}
        <div className="space-y-3">
          {currentQuestion.options?.map((option, index) => (
            <button
              key={index}
              className={`w-full p-4 text-left border-2 rounded-lg transition-colors ${
                selectedAnswer === option
                  ? 'border-primary-500 bg-primary-50'
                  : 'border-gray-200 hover:border-gray-300'
              } ${showResult ? 'pointer-events-none' : ''}`}
              onClick={() => handleAnswerSelect(option)}
              disabled={showResult}
            >
              <span className="font-medium mr-3">
                {String.fromCharCode(65 + index)}.
              </span>
              {option}
              
              {showResult && (
                <span className="float-right">
                  {option === currentQuestion.correctAnswer ? '✅' : 
                   option === selectedAnswer ? '❌' : ''}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Submit Button */}
        {!showResult && (
          <button
            className="btn btn-primary w-full mt-6"
            onClick={handleSubmitAnswer}
            disabled={!selectedAnswer}
          >
            Submit Answer
          </button>
        )}

        {/* Result Display */}
        {showResult && (
          <div className={`mt-6 p-4 rounded-lg ${
            selectedAnswer === currentQuestion.correctAnswer 
              ? 'bg-green-50 border border-green-200' 
              : 'bg-red-50 border border-red-200'
          }`}>
            <div className="text-center">
              <div className="text-2xl mb-2">
                {selectedAnswer === currentQuestion.correctAnswer ? '🎉 Correct!' : '❌ Incorrect'}
              </div>
              {selectedAnswer !== currentQuestion.correctAnswer && (
                <p className="text-sm">
                  The correct answer was: <strong>{currentQuestion.correctAnswer}</strong>
                </p>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}