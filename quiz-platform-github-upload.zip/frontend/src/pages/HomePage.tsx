import { Link } from 'react-router-dom'
import { Play, Users, Trophy, Target } from 'lucide-react'

export default function HomePage() {
  return (
    <div className="max-w-6xl mx-auto">
      {/* Hero Section */}
      <div className="text-center py-16">
        <h1 className="text-5xl font-bold text-gray-900 mb-6">
          Competitive Quiz Platform
        </h1>
        <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
          Test your knowledge in real-time multiplayer trivia battles. 
          Compete with friends, join teams, and climb the leaderboards in the ultimate quiz experience.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link to="/register" className="btn btn-primary text-lg px-8 py-3">
            Get Started
          </Link>
          <Link to="/lobby" className="btn btn-secondary text-lg px-8 py-3">
            Play as Guest
          </Link>
        </div>
      </div>

      {/* Features Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 py-16">
        <div className="card text-center">
          <Play className="h-12 w-12 text-primary-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">Real-time Multiplayer</h3>
          <p className="text-gray-600">
            Compete live against players worldwide with instant updates and fair gameplay.
          </p>
        </div>
        
        <div className="card text-center">
          <Users className="h-12 w-12 text-primary-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">Team Battles</h3>
          <p className="text-gray-600">
            Create teams, invite friends, and compete in collaborative quiz challenges.
          </p>
        </div>
        
        <div className="card text-center">
          <Trophy className="h-12 w-12 text-primary-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">Tournaments</h3>
          <p className="text-gray-600">
            Join elimination tournaments and climb brackets to become the ultimate champion.
          </p>
        </div>
        
        <div className="card text-center">
          <Target className="h-12 w-12 text-primary-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">Smart Scoring</h3>
          <p className="text-gray-600">
            Dynamic scoring system that rewards accuracy, speed, and consistency.
          </p>
        </div>
      </div>

      {/* Stats Section */}
      <div className="bg-primary-600 text-white rounded-2xl p-8 text-center">
        <h2 className="text-3xl font-bold mb-8">Platform Statistics</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          <div>
            <div className="text-4xl font-bold">50+</div>
            <div className="text-primary-100">Questions</div>
          </div>
          <div>
            <div className="text-4xl font-bold">5</div>
            <div className="text-primary-100">Categories</div>
          </div>
          <div>
            <div className="text-4xl font-bold">4</div>
            <div className="text-primary-100">Game Modes</div>
          </div>
          <div>
            <div className="text-4xl font-bold">∞</div>
            <div className="text-primary-100">Fun</div>
          </div>
        </div>
      </div>
    </div>
  )
}