import { useState, useEffect } from 'react'
import { Trophy, Medal, Award, TrendingUp, Users, Target } from 'lucide-react'
import api from '../services/api'

interface LeaderboardEntry {
  rank: number;
  userId: string;
  username: string;
  score: number;
  gamesPlayed: number;
  accuracyRate: number;
  averageScore: number;
}

interface GlobalStats {
  totalPlayers: number;
  totalGames: number;
  totalQuestions: number;
  averageGameScore: number;
  averageAccuracy: number;
  mostPopularCategory: string;
  mostPopularDifficulty: string;
}

export default function LeaderboardPage() {
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([])
  const [globalStats, setGlobalStats] = useState<GlobalStats | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [sortBy, setSortBy] = useState<'totalScore' | 'averageScore' | 'accuracyRate' | 'gamesPlayed'>('totalScore')

  useEffect(() => {
    fetchData()
  }, [sortBy])

  const fetchData = async () => {
    try {
      setLoading(true)
      const [leaderboardResponse, statsResponse] = await Promise.all([
        api.get(`/statistics/leaderboard?sortBy=${sortBy}&limit=50`),
        api.get('/statistics/global')
      ])
      
      setLeaderboard(leaderboardResponse.data.data.leaderboard)
      setGlobalStats(statsResponse.data.data)
    } catch (err) {
      setError('Failed to load leaderboard data')
      console.error('Error fetching leaderboard:', err)
    } finally {
      setLoading(false)
    }
  }

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="h-6 w-6 text-yellow-500" />
      case 2:
        return <Medal className="h-6 w-6 text-gray-400" />
      case 3:
        return <Award className="h-6 w-6 text-amber-600" />
      default:
        return <span className="text-lg font-bold text-gray-600">#{rank}</span>
    }
  }

  const getRankBg = (rank: number) => {
    switch (rank) {
      case 1:
        return 'bg-gradient-to-r from-yellow-50 to-yellow-100 border-yellow-200'
      case 2:
        return 'bg-gradient-to-r from-gray-50 to-gray-100 border-gray-200'
      case 3:
        return 'bg-gradient-to-r from-amber-50 to-amber-100 border-amber-200'
      default:
        return 'bg-white border-gray-200'
    }
  }

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-8"></div>
          <div className="space-y-4">
            {[...Array(10)].map((_, i) => (
              <div key={i} className="card">
                <div className="h-6 bg-gray-200 rounded w-full"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  const getSortLabel = (sortOption: string) => {
    switch (sortOption) {
      case 'totalScore': return 'Total Score';
      case 'averageScore': return 'Average Score';
      case 'accuracyRate': return 'Accuracy Rate';
      case 'gamesPlayed': return 'Games Played';
      default: return 'Total Score';
    }
  }

  const getSortValue = (entry: LeaderboardEntry, sortOption: string) => {
    switch (sortOption) {
      case 'totalScore': return entry.score.toLocaleString();
      case 'averageScore': return entry.averageScore.toFixed(1);
      case 'accuracyRate': return `${entry.accuracyRate.toFixed(1)}%`;
      case 'gamesPlayed': return entry.gamesPlayed.toString();
      default: return entry.score.toLocaleString();
    }
  }

  return (
    <div className="max-w-6xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-2">Leaderboard</h1>
        <p className="text-gray-600">Top players ranked by performance</p>
      </div>

      {/* Global Statistics */}
      {globalStats && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="card text-center">
            <Users className="h-8 w-8 text-blue-500 mx-auto mb-2" />
            <div className="text-2xl font-bold">{globalStats.totalPlayers.toLocaleString()}</div>
            <div className="text-sm text-gray-600">Total Players</div>
          </div>
          <div className="card text-center">
            <Trophy className="h-8 w-8 text-green-500 mx-auto mb-2" />
            <div className="text-2xl font-bold">{globalStats.totalGames.toLocaleString()}</div>
            <div className="text-sm text-gray-600">Games Played</div>
          </div>
          <div className="card text-center">
            <Target className="h-8 w-8 text-purple-500 mx-auto mb-2" />
            <div className="text-2xl font-bold">{globalStats.averageAccuracy.toFixed(1)}%</div>
            <div className="text-sm text-gray-600">Avg Accuracy</div>
          </div>
          <div className="card text-center">
            <TrendingUp className="h-8 w-8 text-orange-500 mx-auto mb-2" />
            <div className="text-2xl font-bold">{globalStats.averageGameScore.toFixed(0)}</div>
            <div className="text-sm text-gray-600">Avg Score</div>
          </div>
        </div>
      )}

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-6">
          {error}
        </div>
      )}

      {/* Sort Options */}
      <div className="card mb-6">
        <div className="flex flex-wrap gap-2">
          <span className="text-sm font-medium text-gray-700 mr-2">Sort by:</span>
          {(['totalScore', 'averageScore', 'accuracyRate', 'gamesPlayed'] as const).map((option) => (
            <button
              key={option}
              onClick={() => setSortBy(option)}
              className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                sortBy === option
                  ? 'bg-primary-500 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {getSortLabel(option)}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        {loading ? (
          <div className="space-y-4">
            {[...Array(10)].map((_, i) => (
              <div key={i} className="card animate-pulse">
                <div className="h-6 bg-gray-200 rounded w-full"></div>
              </div>
            ))}
          </div>
        ) : leaderboard.length === 0 ? (
          <div className="card text-center py-12">
            <Trophy className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">No players yet. Be the first to play!</p>
          </div>
        ) : (
          leaderboard.map((entry) => (
            <div
              key={entry.userId}
              className={`card border-2 ${getRankBg(entry.rank)} transition-all hover:shadow-md`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="flex items-center justify-center w-12 h-12">
                    {getRankIcon(entry.rank)}
                  </div>
                  
                  <div>
                    <h3 className="font-semibold text-lg">{entry.username}</h3>
                    <p className="text-sm text-gray-600">
                      Rank #{entry.rank}
                    </p>
                  </div>
                </div>
                
                <div className="text-right">
                  <div className="text-2xl font-bold text-primary-600">
                    {getSortValue(entry, sortBy)}
                  </div>
                  <div className="text-sm text-gray-600">{getSortLabel(sortBy)}</div>
                </div>
              </div>
              
              <div className="mt-4 grid grid-cols-4 gap-4 pt-4 border-t border-gray-200">
                <div className="text-center">
                  <div className="font-semibold">{entry.score.toLocaleString()}</div>
                  <div className="text-xs text-gray-600">Total Score</div>
                </div>
                <div className="text-center">
                  <div className="font-semibold">{entry.gamesPlayed}</div>
                  <div className="text-xs text-gray-600">Games</div>
                </div>
                <div className="text-center">
                  <div className="font-semibold">{entry.averageScore.toFixed(1)}</div>
                  <div className="text-xs text-gray-600">Avg Score</div>
                </div>
                <div className="text-center">
                  <div className="font-semibold">{entry.accuracyRate.toFixed(1)}%</div>
                  <div className="text-xs text-gray-600">Accuracy</div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}