import api from './api'

export interface LoginRequest {
  email: string
  password: string
}

export interface RegisterRequest {
  username: string
  email: string
  password: string
}

export interface AuthResponse {
  user: {
    id: string
    username: string
    email: string
    createdAt: string
  }
  accessToken: string
  refreshToken: string
}

export interface User {
  id: string
  username: string
  email: string
  createdAt: string
  gamesPlayed: number
  totalScore: number
  averageScore: number
  accuracyRate: number
}

class AuthService {
  async register(data: RegisterRequest): Promise<AuthResponse> {
    const response = await api.post('/auth/register', data)
    return response.data.data
  }

  async login(data: LoginRequest): Promise<AuthResponse> {
    const response = await api.post('/auth/login', data)
    return response.data.data
  }

  async logout(): Promise<void> {
    try {
      await api.delete('/auth/logout')
    } finally {
      localStorage.removeItem('accessToken')
      localStorage.removeItem('refreshToken')
    }
  }

  async getCurrentUser(): Promise<User> {
    const response = await api.get('/auth/me')
    return response.data.data
  }

  isAuthenticated(): boolean {
    return !!localStorage.getItem('accessToken')
  }

  getToken(): string | null {
    return localStorage.getItem('accessToken')
  }

  setTokens(accessToken: string, refreshToken: string): void {
    localStorage.setItem('accessToken', accessToken)
    localStorage.setItem('refreshToken', refreshToken)
  }
}

export default new AuthService()