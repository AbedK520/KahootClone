import api from './api'

export interface UserProfile {
  id: string
  username: string
  email: string
  createdAt: string
  statistics: {
    gamesPlayed: number
    totalScore: number
    averageScore: number
    accuracyRate: number
  }
}

export interface UpdateProfileRequest {
  username?: string
  email?: string
}

export interface UserStats {
  gamesPlayed: number
  totalScore: number
  averageScore: number
  accuracyRate: number
  categoryPerformance: Record<string, number>
}

export interface LeaderboardUser {
  id: string
  username: string
  createdAt: string
  gamesPlayed: number
  totalScore: number
  averageScore: number
  accuracyRate: number
}

class UserService {
  async getProfile(): Promise<UserProfile> {
    const response = await api.get('/users/profile')
    return response.data.data
  }

  async updateProfile(data: UpdateProfileRequest): Promise<UserProfile> {
    const response = await api.put('/users/profile', data)
    return response.data.data
  }

  async getStats(): Promise<UserStats> {
    const response = await api.get('/users/stats')
    return response.data.data
  }

  async getLeaderboard(limit: number = 50, offset: number = 0): Promise<{
    users: LeaderboardUser[]
    pagination: {
      limit: number
      offset: number
      hasMore: boolean
    }
  }> {
    const response = await api.get('/users/leaderboard', {
      params: { limit, offset }
    })
    return response.data.data
  }

  async searchUsers(query: string, limit: number = 20): Promise<LeaderboardUser[]> {
    const response = await api.get('/users/search', {
      params: { q: query, limit }
    })
    return response.data.data
  }
}

export default new UserService()